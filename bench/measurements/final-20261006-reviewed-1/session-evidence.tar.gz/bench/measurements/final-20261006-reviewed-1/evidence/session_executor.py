#!/usr/bin/env python3
"""Session evidence collector. Does not modify implementation or perform manual cleanup."""
import collections,datetime,hashlib,json,os,pathlib,platform,re,subprocess,sys,tempfile,time
ROOT=pathlib.Path.cwd();sys.path.insert(0,str(ROOT/'bench'));import report
SID='final-20261006-reviewed-1'; M=ROOT/'bench/measurements'/SID; E=M/'evidence'; R=ROOT/'bench/results'/SID
EXPECTED_HEAD='ee96b465dc30d6a59933c6d99b499f55194104fc'
BINARY='/tmp/stack-bench-build/target/release/stack'; BINARY_SHA='1d338d2cd92c4ee898037c9ee39dfbccb7c1e3dabae8180fbf65662ac015ce20'; SOURCE='06c351acc6a0744d918dc571c063ff1f6c300700'
def utc():return datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
def dump(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def command(argv):
 p=subprocess.run(argv,capture_output=True,text=True);return dict(argv=argv,exit=p.returncode,stdout=p.stdout,stderr=p.stderr)
def checked(argv):
 r=command(argv)
 if r['exit']:raise RuntimeError(r)
 return r['stdout']
def sources():
 paths=checked(['git','ls-files','-z']).split('\0');return {p:sha(ROOT/p) for p in paths if p and (ROOT/p).is_file()}
def old_results():return {str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'bench/results').rglob('*')) if p.is_file() and R not in p.parents and '__pycache__' not in p.parts}
def snapshot(name):
 cmds={k:command(v) for k,v in {'container_ids':['docker','ps','-aq','--no-trunc'],'network_ids':['docker','network','ls','-q','--no-trunc'],'volume_names':['docker','volume','ls','-q'],'images':['docker','image','ls','--no-trunc','--format','{{json .}}'],'processes':['ps','-axo','pid=,ppid=,state=,lstart=,command=']}.items()}
 for k,v in cmds.items():
  if v['exit']:raise RuntimeError((k,v))
 containers={}
 ids=cmds['container_ids']['stdout'].split()
 if ids:
  for x in json.loads(checked(['docker','inspect',*ids])):
   containers[x['Id']]={k:x.get(k) for k in ['Name','Image','RestartCount']};containers[x['Id']].update(state={k:x['State'].get(k) for k in ['Status','Running','Paused','Restarting','Dead','Pid','ExitCode','StartedAt','FinishedAt']},labels=x['Config'].get('Labels'))
 nets={}
 ids=cmds['network_ids']['stdout'].split()
 if ids:
  for x in json.loads(checked(['docker','network','inspect',*ids])):nets[x['Id']]={k:x.get(k) for k in ['Name','Created','Driver','Scope','Labels','Internal']}
 vols={}
 ids=cmds['volume_names']['stdout'].split()
 if ids:
  for x in json.loads(checked(['docker','volume','inspect',*ids])):vols[x['Name']]={k:x.get(k) for k in ['CreatedAt','Driver','Mountpoint','Labels','Scope','Options']}
 v=dict(utc=utc(),containers=containers,networks=nets,volumes=vols,commands=cmds,tempdirs=sorted(str(p) for p in pathlib.Path(tempfile.gettempdir()).glob('rwb-*')))
 dump(E/(name+'.json'),v);(E/(name+'-processes.txt')).write_text(cmds['processes']['stdout']);return v

def compare(base,now,run_id=None):
 v={}
 for k in ['containers','networks','volumes']:
  v[k]=dict(missing=sorted(set(base[k])-set(now[k])),changed=sorted(x for x in base[k] if x in now[k] and base[k][x]!=now[k][x]),new=sorted(set(now[k])-set(base[k])))
 if run_id:
  tokens=[run_id,re.sub('[^a-zA-Z0-9]','',run_id)]
  v['owned_processes']=[l for l in now['commands']['processes']['stdout'].splitlines() if any(t in l for t in tokens)]
  v['owned_tempdirs']=[p for p in now['tempdirs'] if run_id in p]
  v['owned_image_tags']=[l for l in now['commands']['images']['stdout'].splitlines() if any(t in l for t in tokens)]
 v['safe']=not any(any(v[k][f] for f in ['missing','changed','new']) for k in ['containers','networks','volumes']) and not any(v.get(k) for k in ['owned_processes','owned_tempdirs','owned_image_tags'])
 return v

def verify_run(path,a,plan):
 run,problems=report.load_run(path,a['hashes']);m=run['meta'];steps=run['steps'];out=run['by_check'];lane=plan['protocol']['lanes'][m['tool']]
 logs={str(p.relative_to(path)):sha(p) for p in sorted(path.rglob('*')) if p.is_file()}
 v=dict(run_id=m['run_id'],receipt_problems=problems,all_file_hashes=logs,counts=dict(collections.Counter(o['status'] for o in out.values())),gates=report.run_gates(run,a,plan),actual_versions={},identities={},raw_identity_errors=[],metric_checks={},invalid_checks=[o for o in out.values() if o['status'] in ['fail','blocked','error']])
 for seq,s in steps.items():
  if s['label']=='tool-version' or s['label'].endswith('tool-versions'):
   v['actual_versions'][s['label']]=dict(seq=seq,exit=s['exit'],text=report.log_text(run,s))
  if 'identity' in s['label']:
   texts=report.log_text(run,s)
   for t in texts:
    for line in t.splitlines():
     try:x=json.loads(line)
     except ValueError:continue
     if isinstance(x,dict):v['identities'][s['label']]=dict(seq=seq,receipt=x)
 for metric in report.METRICS:
  val,reason=report.first_task(run,metric[-1]) if metric.startswith('first_task.') else report.repeat(run,metric,plan['session']['sample_policy'])
  v['metric_checks'][metric]=dict(receipt_eligible=val is not None,reason=reason,sample_count=(20 if val and metric.startswith('repeat.') else 1 if val else 0))
 dump(E/(m['tool']+'-verification.json'),v);return v

def prepare():
 assert checked(['git','rev-parse','HEAD']).strip()==EXPECTED_HEAD
 assert sha(BINARY)==BINARY_SHA
 assert not checked(['git','diff',SOURCE,'--','src','Cargo.toml','Cargo.lock'])
 assert not (M/'plan.json').exists() and not R.exists()
 R.mkdir()
 plan=json.loads(checked([sys.executable,'-B','bench/report.py','template','--session-id',SID]))
 plan['session']['serialization_declaration']='Parent explicitly authorizes this declaration. Sole live executor; parent promises no parallel benchmark, build or install task throughout this session. Each of 26 fresh synchronous run.py invocations executes serially in declared roster order with 20 repeats, 3 warmups, keep=false. No diagnostics promoted; unrelated preexisting host services remain running.'
 plan['session']['timing_policy']='First-task A/B are single prepared-checkout observations; repeat20/warmup3 distributions descriptive only; no rank, cold-install, confidence or native-macOS inference. Result review pending; no final timing promotion.'
 plan['session']['result_review']='pending';plan['session']['keep']=False
 host=dict(system=platform.system(),machine=platform.machine(),release=platform.release(),python=platform.python_version())
 plan['protocol']['platform']=dict(host=host,note='macOS host, Docker Desktop Linux ARM64 workloads for docker lanes; host lanes as their committed recipes declare')
 plan['protocol']['cache_policy']='No global cache purge. Prebuilt ev-* images and shared Docker layers/build caches warmed by prior diagnostics; reusable host CLI/download caches retained. Each run has fresh owned checkout/container state. No universal cold-install claims; recipe setup cache notes and realized image IDs retained.'
 approvals=['round-3-report.md','round-4-core.md','round-5-adapters.md','round-2-bad-config.md','round-2-ddev-lando-bootstrap.md','round-2-gitgrove-init.md','round-3-tilt-process.md','round-1-native-transport.md','round-1-devpod-autoresume.md']
 plan['protocol']['source_approvals']=[dict(path='bench/reviews/'+p,sha256=sha(ROOT/'bench/reviews'/p)) for p in approvals]
 plan['protocol']['reporter_sha256']=sha(ROOT/'bench/report.py')
 plan['protocol']['stack']=dict(source_revision=SOURCE,binary_sha256=BINARY_SHA,binary_path=BINARY,build_receipt=dict(path='bench/provenance/stack-20261006/original-stack-build-thread-receipts.json',sha256=sha(ROOT/'bench/provenance/stack-20261006/original-stack-build-thread-receipts.json')))
 previous={}
 for p in (ROOT/'bench/results').rglob('meta.json'):
  try:m=json.loads(p.read_text())
  except:continue
  t=m.get('tool')
  if t and m.get('started_unix_ns',0)>previous.get(t,({},None))[0].get('started_unix_ns',-1):previous[t]=(m,p)
 from rwb.adapters import registry
 for row in plan['session']['roster']:
  t=row['tool'];m,p=previous[t];options=dict(m.get('options') or {})
  if t=='stack':options.update(stack_binary=BINARY,stack_sha256=BINARY_SHA)
  cls,var=registry.load(t);ad=cls(options,var,'plan');lane=plan['protocol']['lanes'][t]
  lane.update(options=options,pins=ad.pins,cache_note=ad.cache_note,image=ad.image,prior_options_receipt=str(p.relative_to(ROOT)),deviations=[v for k,v in ad.pins.items() if k in ['deviation','note','image_notes']])
  if ad.transport=='docker':
   receipt=json.loads(checked(['docker','image','inspect',ad.image]));lane['image_id']=receipt[0]['Id'];dump(E/(t+'-image-before.json'),receipt)
  oldsteps=p.parent/'steps.jsonl'
  if oldsteps.exists():
   for line in oldsteps.read_text().splitlines():
    st=json.loads(line)
    if st.get('label')=='tool-version' and st.get('exit')==0:
     txt=(p.parent/st['stdout']).read_text() if isinstance(st.get('stdout'),str) else ''
     if txt.strip():lane['version_contains']=[txt.splitlines()[0][:80]]
  row.update(path=str((R/t).relative_to(ROOT)),options=options)
  row['argv']=[sys.executable,'-B','bench/run.py','--tool',t,'--out',row['path'],'--repeats','20','--warmups','3']+[x for k,v in options.items() for x in ['--option',f'{k}={v}']]
 base=snapshot('baseline');assert len(base['containers'])==27
 inventory=dict(source_files=sources(),preexisting_results=old_results(),host_receipts={k:command(v) for k,v in {'docker_info':['docker','info'],'docker_version':['docker','version'],'docker_context':['docker','context','show'],'host_resources':['sysctl','hw.ncpu','hw.memsize'],'load':['uptime'],'memory':['vm_stat'],'disk':['df','-h',str(ROOT)],'binary_identity':['file',BINARY]}.items()})
 dump(E/'baseline-integrity.json',inventory)
 plan['protocol']['baseline']=dict(path=str((E/'baseline.json').relative_to(ROOT)),sha256=sha(E/'baseline.json'),integrity_path=str((E/'baseline-integrity.json').relative_to(ROOT)),integrity_sha256=sha(E/'baseline-integrity.json'))
 plan['session']['plan_created_utc']=utc();report.check_manifest(plan)
 with (M/'plan.json').open('x') as f:f.write(json.dumps(plan,indent=2,sort_keys=True)+'\n')
 os.chmod(M/'plan.json',0o444)
 dump(M/'plan-receipt.json',dict(path=str((M/'plan.json').relative_to(ROOT)),sha256=sha(M/'plan.json'),creation_utc=plan['session']['plan_created_utc'],sealed_utc=utc()))
 print('SEALED',sha(M/'plan.json'),len(plan['session']['roster']),flush=True)

def execute():
 plan=json.loads((M/'plan.json').read_text());sealed=json.loads((M/'plan-receipt.json').read_text());base=json.loads((E/'baseline.json').read_text());inventory=json.loads((E/'baseline-integrity.json').read_text());manifest=json.loads(json.dumps(plan));manifest['plan_receipt']=sealed
 assert not (M/'manifest.json').exists()
 for i,row in enumerate(plan['session']['roster'],1):
  assert sha(M/'plan.json')==sealed['sha256'];assert sources()==inventory['source_files']
  print(f"START {i}/26 {row['tool']} {utc()}",flush=True)
  start=time.time_ns();p=subprocess.run(row['argv'],capture_output=True,text=True);end=time.time_ns()
  (E/(row['tool']+'-launcher.stdout')).write_text(p.stdout);(E/(row['tool']+'-launcher.stderr')).write_text(p.stderr)
  dump(E/(row['tool']+'-launcher.json'),dict(argv=row['argv'],exit=p.returncode,started_unix_ns=start,finished_unix_ns=end,stdout_sha256=sha(E/(row['tool']+'-launcher.stdout')),stderr_sha256=sha(E/(row['tool']+'-launcher.stderr'))))
  path=ROOT/row['path'];a=json.loads(checked([sys.executable,'-B','bench/report.py','attempt','--run',row['path']]))
  a['result_review']=None;a['review_status']='pending'
  if row['tool']=='stack':a['stack']=plan['protocol']['stack']
  if row['tool']=='ddev':a['classification']='adapter-blocker';a['reason']='Frozen adapter tries download-images pull of not-yet-built local app image; no normal DDEV startup performance or product failure inference.'
  m=json.loads((path/'meta.json').read_text())
  if m.get('blocked'):a['classification']='environment-blocker';a['reason']=m['blocked']
  v=verify_run(path,a,plan);now=snapshot('after-'+row['tool']);comp=compare(base,now,m['run_id']);dump(E/('after-'+row['tool']+'-comparison.json'),comp)
  manifest['attempts'].append(a);dump(M/'manifest.json',manifest)
  print(f"DONE {i}/26 {row['tool']} exit={p.returncode} valid={m['valid']} checks={v['counts']} cleanup_safe={comp['safe']} {utc()}",flush=True)
  if not comp['safe'] or m.get('cleanup_problems'):raise RuntimeError('Safety/cleanup ambiguity; no cleanup or next lane authorized. See exact receipts.')
 final=snapshot('final');comp=compare(base,final);dump(E/'final-comparison.json',comp)
 current=sources();old=old_results();ints=[]
 for a in manifest['attempts']:
  m=json.loads((ROOT/a['path']/'meta.json').read_text());ints.append(dict(tool=a['tool'],start=m['started_unix_ns'],end=m['finished_unix_ns']))
 integrity=dict(source_unchanged=current==inventory['source_files'],old_results_unchanged=old==inventory['preexisting_results'],old_result_files=len(old),intervals=ints,nonoverlap=all(b['start']>=a['end'] for a,b in zip(ints,ints[1:])),plan_unchanged=sha(M/'plan.json')==sealed['sha256'],baseline_preserved=comp['safe'],binary_unchanged=sha(BINARY)==BINARY_SHA,head=checked(['git','rev-parse','HEAD']).strip(),result_review='pending')
 dump(E/'final-integrity.json',integrity)
 print('FINISHED',json.dumps({k:v for k,v in integrity.items() if k!='intervals'}),flush=True)
if __name__=='__main__':{'prepare':prepare,'execute':execute}[sys.argv[1]]()
