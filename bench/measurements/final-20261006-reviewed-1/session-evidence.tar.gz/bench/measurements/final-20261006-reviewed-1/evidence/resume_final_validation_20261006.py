"""Read-only checks of all final receipts, with pending-review reportability."""
import importlib.util,pathlib,json,sys,collections,re,datetime
ROOT=pathlib.Path.cwd();p=ROOT/'bench/measurements/final-20261006-reviewed-1/evidence/resume_executor_20261006.py';s=importlib.util.spec_from_file_location('resume',p);resume=importlib.util.module_from_spec(s);s.loader.exec_module(resume);h=resume.h
assert not h.checked(['git','diff',h.SOURCE,'--','src','Cargo.toml','Cargo.lock'])
manifest=json.loads((h.M/'manifest.json').read_text());h.report.check_manifest(manifest);resume.unchanged()
selected=[a for a in manifest['attempts'] if a['state']!='excluded'];assert len(selected)==26 and len(manifest['attempts'])==27
assert [a['tool'] for a in selected]==[r['tool'] for r in manifest['session']['roster']]
rows=[];intervals=[];totals=collections.Counter();allhashes={};ownership=[];descriptors=[]
for a in selected:
 descriptor=h.command([sys.executable,'-B','bench/report.py','attempt','--run',a['path']]);assert descriptor['exit']==0;observed=json.loads(descriptor['stdout']);assert all(observed[k]==a[k] for k in ['tool','variant','path','run_id','hashes']);descriptors.append(dict(tool=a['tool'],command=descriptor))
 path=ROOT/a['path'];r,problems=h.report.load_run(path,a['hashes']);assert r is not None and not problems,(a['tool'],problems)
 m=r['meta'];assert m['completed'] and m['valid'] and not m['keep'] and m['reportable'] is False and not m['errors'] and not m['cleanup_problems']
 gates=h.report.run_gates(r,a,manifest)
 structural=[x for x in gates if x not in ['session has no review reference','attempt has no result-review reference'] and not x.startswith(('incomplete outcomes:','provisioning blocked:')) and not (m.get('blocked') and x=='no single successful tool-version receipt')]
 assert not structural,(a['tool'],structural)
 counts=dict(collections.Counter(o['status'] for o in r['outcomes']));totals.update(counts);totals['steps']+=len(r['steps']);totals['attempts']+=1;totals['raw_log_references']+=2*len(r['steps'])
 interval=dict(tool=a['tool'],run_id=a['run_id'],start=m['started_unix_ns'],end=m['finished_unix_ns'],started_utc=m['started_utc'],finished_utc=m['finished_utc']);intervals.append(interval)
 checks={}
 for metric in h.report.METRICS:
  val,reason=h.report.first_task(r,metric[-1]) if metric.startswith('first_task.') else h.report.repeat(r,metric,manifest['session']['sample_policy'])
  checks[metric]=dict(receipts_eligible=val is not None,receipt_reason=reason,eligible_after_run_gates_except_review=val is not None and all(x in ['session has no review reference','attempt has no result-review reference'] for x in gates),published=False)
 hashes={str(f.relative_to(path)):h.sha(f) for f in sorted(path.rglob('*')) if f.is_file()};allhashes[a['path']]=hashes
 rows.append(dict(tool=a['tool'],path=a['path'],run_id=a['run_id'],interval=interval,counts=counts,run_gate_problems=gates,missing_outcomes=sorted(set(h.report.MAIN_CHECKS)-set(r['by_check'])),invalid_checks=[o for o in r['outcomes'] if o['status'] in ['fail','blocked','error']],versions={st['label']:dict(seq=st['seq'],exit=st['exit'],text=h.report.log_text(r,st)) for st in r['steps'].values() if st['label']=='tool-version' or st['label'].endswith('tool-versions')},pins=m['pins'],deviations=manifest['protocol']['lanes'][a['tool']]['deviations'],metric_eligibility=checks,receipt_problems=problems,source_hashes_match=True,raw_file_count=len(hashes),artifact_files=sum('artifacts' in f.parts for f in path.rglob('*') if f.is_file()),blocked=m.get('blocked')))
assert all(b['start']>=a['end'] for a,b in zip(intervals,intervals[1:]))
# The interrupted attempt has no end timestamp. Its confirmed container removal bounds ownership.
excluded=next(a for a in manifest['attempts'] if a['state']=='excluded');partial=json.loads((ROOT/excluded['path']/'meta.json').read_text());rem=json.loads((h.E/'resume-20261006-interrupted-container-removal.json').read_text());confirmed=json.loads((h.E/'resume-20261006-clean-baseline.json').read_text())['utc'];rem_ns=h.report.utc_ns(confirmed);retry=next(i for i in intervals if i['tool']=='dnvr');assert partial['started_unix_ns']>=intervals[14]['end'] and retry['start']>=rem_ns
assert retry['start']>=h.report.utc_ns(json.loads((h.M/'resume-plan-20261006.json').read_text())['creation_utc'])
now=h.snapshot('resume-final-validation');base=json.loads((h.E/'baseline.json').read_text());comp=h.compare(base,now);h.dump(h.E/'resume-final-validation-comparison.json',comp);assert comp['safe'] and len(now['containers'])==27
for a in manifest['attempts']:
 rid=a['run_id'];c=h.compare(base,now,rid);assert c['safe'],(a['tool'],c);ownership.append(dict(tool=a['tool'],run_id=rid,comparison=c))
# Read-only reporter build; reviews remain null so no final metric can be published.
report=h.report.build(manifest,h.M/'manifest.json');assert not report['reported_timings'],report['reported_timings'];assert all(r['covered'] for r in report['roster']),report['roster']
h.dump(h.E/'resume-pending-review-report-verification.json',report)
inv=json.loads((h.E/'baseline-integrity.json').read_text());reuse=json.loads((h.E/'resume-20261006-reuse-verification.json').read_text());summary=dict(utc=h.utc(),head=h.checked(['git','rev-parse','HEAD']).strip(),all26_evidence_covered=True,selected_attempts=26,total_attempts=27,excluded_attempt=excluded,nonoverlap=True,intervals=intervals,interruption=dict(last_completed_receipt_utc='2026-10-06T17:50:25Z',initial_resumption_utc=json.loads((h.E/'resume-20261006-initial.json').read_text())['utc'],owned_container_removal_command_utc=rem['utc'],owned_container_removed_utc=confirmed,supplement_creation_utc=json.loads((h.M/'resume-plan-20261006.json').read_text())['creation_utc'],retry_started_utc=retry['started_utc'],whole_host_idle_claim=False,uninterrupted_session_claim=False),source_unchanged=h.sources()==inv['source_files'],preexisting_results_unchanged=h.old_results()==inv['preexisting_results'],first15_unchanged=True,partial_dnvr_unchanged=True,plan_unchanged=h.sha(h.M/'plan.json')==resume.PLAN_SHA,resume_helper_unchanged=h.sha(h.E/'resume_executor_20261006.py')==json.loads((h.M/'resume-plan-20261006.json').read_text())['resume_helper_sha256'],binary_unchanged=h.sha(h.BINARY)==h.BINARY_SHA,baseline_preserved=comp['safe'],ownership=ownership,totals=dict(totals),lanes=rows,all_run_file_hashes=allhashes,result_review='pending',reported_metrics=0,historical_helpers_unchanged=h.sha(h.E/'session_executor.py')==json.loads((h.M/'resume-plan-20261006.json').read_text())['historical_helper_sha256'] and h.sha(h.E/'independent_review_evidence.py')==json.loads((h.M/'resume-plan-20261006.json').read_text())['historical_independent_helper_sha256'])
h.dump(h.E/'resume-all26-attempt-descriptors.json',descriptors);h.dump(h.E/'resume-final-integrity.json',summary);print(json.dumps({k:v for k,v in summary.items() if k not in ['ownership','lanes','all_run_file_hashes','excluded_attempt','intervals']},indent=2))
