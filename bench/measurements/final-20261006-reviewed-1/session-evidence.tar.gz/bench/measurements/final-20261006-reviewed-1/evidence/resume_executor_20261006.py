#!/usr/bin/env python3
"""Resume only. Historical collectors and plan remain untouched."""
import importlib.util,json,pathlib,sys,time,copy,os
ROOT=pathlib.Path.cwd()
p=ROOT/'bench/measurements/final-20261006-reviewed-1/evidence/session_executor.py'
s=importlib.util.spec_from_file_location('historical_collector',p);h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
E=h.E;M=h.M;R=h.R
PLAN_SHA='d051730e7b85f9c83eb842abbfa64bf8d76a358195487d8b9aac10b78ff4e74e'
def unchanged():
 inv=json.loads((E/'baseline-integrity.json').read_text())
 assert h.sha(M/'plan.json')==PLAN_SHA
 assert h.checked(['git','rev-parse','HEAD']).strip()==h.EXPECTED_HEAD
 assert h.sources()==inv['source_files']
 assert h.old_results()==inv['preexisting_results']
 assert h.sha(h.BINARY)==h.BINARY_SHA
 reuse=json.loads((E/'resume-20261006-reuse-verification.json').read_text())
 for x in reuse['completed']:
  path=R/x['tool'];assert {str(p.relative_to(path)):h.sha(p) for p in path.rglob('*') if p.is_file()}==x['all_file_hashes']
 d=R/'dnvr';assert {str(p.relative_to(d)):h.sha(p) for p in d.rglob('*') if p.is_file()}==json.loads((E/'resume-20261006-interrupted-raw-hashes.json').read_text())
def prepare():
 unchanged();plan=json.loads((M/'plan.json').read_text());manifest=json.loads((M/'manifest.json').read_text());assert len(manifest['attempts'])==15
 with (E/'pre-resume-manifest.json').open('x') as f:f.write((M/'manifest.json').read_text())
 rows=copy.deepcopy(plan['session']['roster'][15:]);rows[0]['path']=str((R/'dnvr-retry-1').relative_to(ROOT));rows[0]['argv'][rows[0]['argv'].index('--out')+1]=rows[0]['path']
 for row in rows:assert not (ROOT/row['path']).exists()
 partial=R/'dnvr';meta=json.loads((partial/'meta.json').read_text());desc=h.command([sys.executable,'-B','bench/report.py','attempt','--run',str(partial.relative_to(ROOT))]);h.dump(E/'interrupted-dnvr-attempt-descriptor-command.json',desc)
 excluded=dict(tool='dnvr',variant=meta['variant'],state='excluded',path=str(partial.relative_to(ROOT)),run_id=meta['run_id'],reason='Prior task cancelled during repeat.app_read after sample 009. Executor absent on fresh resumption snapshot; completed/outcomes/final interval absent. Partial raw receipts preserved unchanged. Exact owned container captured and removed after fresh identity confirmation; dnvr retried at dnvr-retry-1. Never timing eligible.',result_review=None,review_status='pending',hashes={n:h.sha(partial/n) if (partial/n).is_file() else None for n in h.report.EVIDENCE_FILES},classification='interrupted')
 excluded['hashes']['tree']=h.report.tree_digest(partial);manifest['attempts'].append(excluded)
 supplement=dict(schema='rwb-resume-supplement/1',creation_utc=h.utc(),original_plan=dict(path=str((M/'plan.json').relative_to(ROOT)),sha256=PLAN_SHA,creation_utc='2026-10-06T17:19:10Z'),authorization='User explicitly authorizes this sole executor to resume frozen26tool measurement; parent promises no workers or builds during resumption.',serialization='Eleven fresh run.py invocations serially in remaining original roster order, beginning dnvr retry. 20 repeats, 3 warmups, keep=false. Existing 15 completed attempts unchanged. No claim of uninterrupted execution or whole-host idleness across cancellation/resumption. Original preexisting services remain running.',interruption=dict(run_id=meta['run_id'],started_utc=meta['started_utc'],last_receipt_utc='2026-10-06T17:50:25Z',cancel_time='not observed by this executor',resumption_snapshot='bench/measurements/final-20261006-reviewed-1/evidence/resume-20261006-initial.json',clean_baseline='bench/measurements/final-20261006-reviewed-1/evidence/resume-20261006-clean-baseline.json',excluded_attempt=excluded),sample_policy=plan['session']['sample_policy'],remaining_ordered_attempts=rows,result_review='pending',historical_helper_sha256=h.sha(p),historical_independent_helper_sha256=h.sha(E/'independent_review_evidence.py'),resume_helper_sha256=h.sha(pathlib.Path(__file__)))
 sp=M/'resume-plan-20261006.json'
 with sp.open('x') as f:f.write(json.dumps(supplement,indent=2,sort_keys=True)+'\n')
 os.chmod(sp,0o444);receipt=dict(path=str(sp.relative_to(ROOT)),sha256=h.sha(sp),creation_utc=supplement['creation_utc'],sealed_utc=h.utc());h.dump(M/'resume-plan-20261006-receipt.json',receipt)
 manifest['resume_plan_receipt']=receipt;manifest['session']['resumption_declaration']=supplement['serialization'];manifest['session']['result_review']='pending';h.report.check_manifest(manifest);h.dump(M/'manifest.json',manifest)
 print('RESUME SEALED',receipt,flush=True)
def execute():
 supplement=json.loads((M/'resume-plan-20261006.json').read_text());receipt=json.loads((M/'resume-plan-20261006-receipt.json').read_text());assert h.sha(M/'resume-plan-20261006.json')==receipt['sha256'];plan=json.loads((M/'plan.json').read_text());base=json.loads((E/'baseline.json').read_text());manifest=json.loads((M/'manifest.json').read_text());assert len(manifest['attempts'])==16
 for i,row in enumerate(supplement['remaining_ordered_attempts'],16):
  unchanged();assert h.sha(M/'resume-plan-20261006.json')==receipt['sha256'];assert not (ROOT/row['path']).exists();print(f"START {i}/26 {row['tool']} {h.utc()}",flush=True)
  start=time.time_ns();r=h.command(row['argv']);end=time.time_ns();key='resume-'+row['tool'];h.dump(E/(key+'-launcher.json'),dict(**r,started_unix_ns=start,finished_unix_ns=end))
  path=ROOT/row['path'];descriptor=h.command([sys.executable,'-B','bench/report.py','attempt','--run',row['path']]);h.dump(E/(key+'-attempt-descriptor-command.json'),descriptor);assert descriptor['exit']==0,descriptor
  a=json.loads(descriptor['stdout']);a.update(result_review=None,review_status='pending');m=json.loads((path/'meta.json').read_text())
  if m.get('blocked'):a.update(classification='environment-blocker',reason=m['blocked'])
  v=h.verify_run(path,a,plan);now=h.snapshot(key+'-after');comp=h.compare(base,now,m['run_id']);h.dump(E/(key+'-after-comparison.json'),comp)
  manifest['attempts'].append(a);h.report.check_manifest(manifest);h.dump(M/'manifest.json',manifest)
  print(f"DONE {i}/26 {row['tool']} exit={r['exit']} valid={m['valid']} checks={v['counts']} cleanup_safe={comp['safe']} {h.utc()}",flush=True)
  if not comp['safe'] or m.get('cleanup_problems'):raise RuntimeError('Ownership/cleanup ambiguity; inspect exact current state before any next attempt.')
 unchanged();now=h.snapshot('resume-final');comp=h.compare(base,now);h.dump(E/'resume-final-comparison.json',comp);assert comp['safe'];print('ALL 26 COVERED; pending final independent receipt checks',flush=True)
if __name__=='__main__':{'prepare':prepare,'execute':execute}[sys.argv[1]]()
