"""Read-only reparse of final receipts for result review; does not promote timings."""
import collections,json,pathlib,re,sys
ROOT=pathlib.Path.cwd();sys.path.insert(0,str(ROOT/'bench'));import report
from rwb import verify
from rwb.adapters import registry
M=ROOT/'bench/measurements/final-20261006-reviewed-1';E=M/'evidence'
def objects(text):
 vals=[]
 for line in text.splitlines():
  try:x=json.loads(line)
  except ValueError:continue
  if isinstance(x,dict):vals.append(x)
 return vals
def payload(run,step,cmd):
 for x in objects(report.log_text(run,step)[0]):
  if x.get('command')==cmd or cmd=='identity' and x.get('command')=='wait':return verify.app_result(x,x['command'],step['exit'],step['timed_out'])
 raise ValueError('no app JSON '+cmd)
def last_map(run,co,seq):
 steps=[s for s in run['steps'].values() if s['label']==co+'-port-map' and s['seq']>seq]
 if not steps:return None
 s=steps[0];o=objects(report.log_text(run,s)[0]);return o[-1] if s['exit']==0 and o else None
manifest=json.loads((M/'manifest.json').read_text());all_lanes={};totals=collections.Counter()
for a in manifest['attempts']:
 if a['state']=='excluded':continue
 run,problems=report.load_run(a['path'],a['hashes']);meta=run['meta'];steps=run['steps'];by=run['by_check'];lane={ 'run_id':a['run_id'],'receipt_problems':problems,'identities':{},'repeat_counts':{},'outcome_counts':dict(collections.Counter(o['status'] for o in by.values())),'checks_with_failures_or_blocks':[o for o in by.values() if o['status'] in ['fail','blocked','error']],'metric_receipt_eligibility':{},'run_gate_problems':report.run_gates(run,a,manifest)}
 ids={}
 cls,var=registry.load(a['tool']);ad=cls(meta.get('options') or {},var,meta['run_id'])
 if meta['transport']=='host':
  bodies='\n'.join(st.get('body','') for st in steps.values() if st['label'].endswith('-prepare'))
  roots=re.findall(r'(/[^\s\'\"]*/rwb-'+re.escape(meta['run_id'])+r'-[^/\s\'\"]+/w)(?=/|[\s\'\"]|$)',bodies)
  assert roots, ('no host root',a['tool'])
  ad.root=roots[0]
 for co in ['a','b']:
  candidates=[s for s in steps.values() if s['label']==co+'-start-identity']
  if not candidates:lane['identities'][co]={'executed':False};continue
  s=candidates[0]
  try:
   ident=payload(run,s,'identity');ids[co]=ident
   preps=[x for x in steps.values() if x['label']==co+'-prepare'];prep=preps[0] if preps else None
   body=prep.get('body','') if prep else ''
   token=ident['source']['token'];token_lines=[l for l in body.splitlines() if token in l and 'SOURCE_TOKEN' in l]
   writes=[dict(seq=st['seq'],label=st['label'],exit=st['exit'],line=l) for st in steps.values() if st['label'] in [co+'-prepare',co+'-setup'] and st['seq']<s['seq'] for l in st.get('body','').splitlines() if token in l and 'SOURCE_TOKEN' in l]
   source_written=len(writes)==1 and writes[0]['exit']==0
   expected_path=ad.app_source_path(ad.checkout(co,0 if co=='a' else 1,token));pm=last_map(run,co,s['seq']);issue=verify.identity_problems(ident,token=token,path=expected_path,port_map=pm)
   lane['identities'][co]=dict(executed=True,identity_seq=s['seq'],prepare_seq=prep['seq'] if prep else None,source_token_in_prepare=len(token_lines)==1,source_write_lines=token_lines,source_token_written=source_written,source_write_receipts=writes,port_map=pm,identity_problems=issue,actual=ident,expected_path=expected_path)
  except Exception as ex:lane['identities'][co]=dict(executed=True,error=str(ex),seq=s['seq'])
 if set(ids)=={'a','b'}:
  keys={co:verify.isolation_key(x,meta['isolation_boundary']) for co,x in ids.items()};lane['isolation']=dict(boundary=meta['isolation_boundary'],keys=keys,distinct_pg=keys['a']['pg']!=keys['b']['pg'],distinct_redis=keys['a']['redis']!=keys['b']['redis'],different_source_tokens=ids['a']['source']['token']!=ids['b']['source']['token'],outcome=by.get('isolation'))
 restarts=[s for s in steps.values() if s['label']=='a-restart-identity']
 if restarts and 'a' in ids:
  try:
   ident=payload(run,restarts[0],'identity');lane['restart_independent']=dict(seq=restarts[0]['seq'],same_pg_data=verify.same_pg_data(ids['a'],ident),pg_markers=ident['pg_markers'],redis_marker=ident.get('redis_marker'),redis_appendonly=ident['redis'].get('appendonly'),redis_dir=ident['redis'].get('dir'))
  except Exception as ex:lane['restart_independent']={'error':str(ex)}
 for metric in report.METRICS:
  val,reason=report.first_task(run,metric[-1]) if metric.startswith('first_task.') else report.repeat(run,metric,manifest['session']['sample_policy'])
  lane['metric_receipt_eligibility'][metric]=dict(eligible_before_review_and_run_gates=val is not None,reason=reason)
  if metric.startswith('repeat.'):
   group=[s for s in steps.values() if s['label'].startswith(metric+'-')];warm=[s for s in group if '-warmup-' in s['label']];samples=[s for s in group if '-sample-' in s['label']]
   lane['repeat_counts'][metric]=dict(warmups=len(warm),samples=len(samples),warmup_success=sum(s['exit']==0 and not s['timed_out'] for s in warm),sample_success=sum(s['exit']==0 and not s['timed_out'] for s in samples),sample_inner_present=sum(s.get('inner_ns') is not None for s in samples),sample_sequences=[s['seq'] for s in samples])
   totals[metric+'.samples']+=len(samples);totals[metric+'.warmups']+=len(warm)
   if metric=='repeat.app_read':
    bad=[]
    for s in group:
     try:x=payload(run,s,'read');assert x['item']['sku']=='keeper-a'
     except Exception as ex:bad.append(dict(seq=s['seq'],error=str(ex)))
    lane['repeat_counts'][metric]['semantic_problems']=bad
 lane['artifacts']={str(p.relative_to(run['path'])):dict(bytes=p.stat().st_size,sha256=report.sha256_file(p)) for p in sorted((run['path']/'artifacts').rglob('*')) if p.is_file()}
 lane['raw_versions']={s['label']:dict(seq=s['seq'],exit=s['exit'],text=report.log_text(run,s)) for s in steps.values() if s['label']=='tool-version' or s['label'].endswith('tool-versions')}
 totals['attempts']+=1;totals['steps']+=len(steps);totals['raw_log_files']+=2*len(steps);totals['artifacts']+=len(lane['artifacts']);all_lanes[a['tool']]=lane
(E/'resume-independent-result-evidence.json').write_text(json.dumps(dict(result_review='pending',totals=dict(totals),lanes=all_lanes),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(totals)))
