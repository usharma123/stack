# Dev Containers CLI (devcontainers:default) run 20261006t173334-55bcb5

valid: True · completed: True · transport: host · isolation boundary: container
measurement: diagnostic: timings recorded per check; only passing checks' samples count · reportable: False

Setup scope: devcontainer build: builds the app image; base images pull and uv sync (postCreateCommand) run in `up`
Cache state: host Docker image cache and the pinned CLI download are reused across runs; A pulls/builds only images missing from the host cache, B reuses A's

| check | status | mode | detail |
|---|---|---|---|
| setup.a | pass | scripted |  |
| lock.created | pass | scripted |  |
| deps.a | pass | native |  |
| start.a | pass | native | readiness=native pg=5432 redis=6379 |
| migrate.a | pass | native |  |
| crud_cache.a | pass | native |  |
| tests.a | pass | native |  |
| start.repeat | pass | native | start exit 0 |
| setup.b | pass | scripted |  |
| deps.b | pass | native |  |
| start.b | pass | native | readiness=native pg=5432 redis=6379 |
| migrate.b | pass | native |  |
| crud_cache.b | pass | native |  |
| tests.b | pass | native |  |
| isolation | pass | native | boundary=container |
| repeat.entry | pass | native |  |
| repeat.app_read | pass | native |  |
| status | observed | scripted | exit 0 |
| stop.a | pass | scripted | stop exit 0, probe exit 0, app after stop exit 1 |
| b.survives | pass | n/a |  |
| restart.a | pass | native | readiness=native pg=5432 redis=6379 |
| persist.pg | pass | native |  |
| persist.redis | pass | native | policy={'appendonly': 'yes', 'appendfsync': 'always', 'save': '3600 1 300 100 60 10000', 'dir': '/data'} |
| cache.after_restart | pass | native |  |
| lock.frozen_copy | pass | scripted | setup exit 0; lock unchanged; versions match |
| bad_config | pass | scripted | setup exit 1 (intended diagnostic) |
| occupied_port | not_applicable | n/a | no host port is published for PostgreSQL/Redis; each checkout uses internal ports on its own Compose network, so a host listener cannot collide |
| cleanup.processes | pass | scripted |  |
| cleanup.supervisors | observed | n/a | none |

End-to-end time to first verified work (setup, start, readiness, app deps, identity,
migrate, mark/CRUD/cache, pytest). `steps` sums those receipts; `wall` also includes
harness verification steps. This, not any single setup command, is the cross-tool task time.
It starts from an already PREPARED checkout; prepare (reported separately as prepare.<co>) covers: benchmark glue only: fixture + tool config copy, source token.

| task | steps s | wall s | receipts | checkout |
|---|---|---|---|---|
| first_task.a | 14.23 | 15.71 | 9 | first in run |
| first_task.b | 13.24 | 14.72 | 9 | second, A's lock, warm caches |

Phase timings (single commands; scopes differ by tool, see Setup scope; do not rank across tools):

| timing | outer p50 ms | outer p95 ms | inner p50 ms | inner p95 ms | ok/n |
|---|---|---|---|---|---|
| deps.first_checkout (single, outer) | 454.6 | | | | 1/1 |
| deps.second_checkout (single, outer) | 478.9 | | | | 1/1 |
| prepare.a (single, outer) | 30.0 | | | | 1/1 |
| prepare.b (single, outer) | 38.7 | | | | 1/1 |
| prepare.c (single, outer) | 45.0 | | | | 1/1 |
| prepare.d (single, outer) | 70.6 | | | | 1/1 |
| ready.a (single, outer) | 3372.3 | | | | 1/1 |
| ready.b (single, outer) | 6692.0 | | | | 1/1 |
| repeat.app_read | 947.126 | 1081.168 | None | None | 20/20 |
| repeat.entry | 355.302 | 387.364 | None | None | 20/20 |
| setup.first_checkout (single, outer) | 1930.0 | | | | 1/1 |
| setup.second_checkout (single, outer) | 1057.8 | | | | 1/1 |

`ready.<co>` sums start, native readiness and the first verified identity (app deps excluded).
First-checkout timings start from the image's cache state above; they are not universal cold installs.
