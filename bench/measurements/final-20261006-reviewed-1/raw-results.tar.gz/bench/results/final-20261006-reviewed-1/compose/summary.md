# Docker Compose (compose:default) run 20261006t173215-62be8d

valid: True · completed: True · transport: host · isolation boundary: container
measurement: diagnostic: timings recorded per check; only passing checks' samples count · reportable: False

Setup scope: `config --lock-image-digests` (A only) + `pull postgres redis` + `build app` (Python deps via `uv sync --frozen` in the image); containers are created at `up`
Cache state: host Docker image/build cache not cleared (base images may already be present); B reuses A's layers on the same daemon

| check | status | mode | detail |
|---|---|---|---|
| setup.a | pass | native |  |
| lock.created | pass | native |  |
| deps.a | pass | native |  |
| start.a | pass | native | readiness=native pg=5432 redis=6379 |
| migrate.a | pass | native |  |
| crud_cache.a | pass | native |  |
| tests.a | pass | native |  |
| start.repeat | pass | native | start exit 0 |
| setup.b | pass | native |  |
| deps.b | pass | native |  |
| start.b | pass | native | readiness=native pg=5432 redis=6379 |
| migrate.b | pass | native |  |
| crud_cache.b | pass | native |  |
| tests.b | pass | native |  |
| isolation | pass | native | boundary=container |
| repeat.entry | pass | native |  |
| repeat.app_read | pass | native |  |
| status | observed | native | exit 0 |
| stop.a | pass | native | stop exit 0, probe exit 0, app after stop exit 1 |
| b.survives | pass | n/a |  |
| restart.a | pass | native | readiness=native pg=5432 redis=6379 |
| persist.pg | pass | native |  |
| persist.redis | pass | native | policy={'appendonly': 'yes', 'appendfsync': 'always', 'save': '3600 1 300 100 60 10000', 'dir': '/data'} |
| cache.after_restart | pass | native |  |
| lock.frozen_copy | pass | n/a | setup exit 0; lock unchanged; versions match |
| bad_config | pass | native | setup exit 1 (intended diagnostic) |
| occupied_port | not_applicable | n/a | no host ports are published: services listen inside each project's own network, so a squatted host port tests nothing Compose owns |
| cleanup.processes | pass | native |  |
| cleanup.supervisors | observed | n/a | none |

End-to-end time to first verified work (setup, start, readiness, app deps, identity,
migrate, mark/CRUD/cache, pytest). `steps` sums those receipts; `wall` also includes
harness verification steps. This, not any single setup command, is the cross-tool task time.
It starts from an already PREPARED checkout; prepare (reported separately as prepare.<co>) covers: benchmark glue only: fixture + tool config copy, source token.

| task | steps s | wall s | receipts | checkout |
|---|---|---|---|---|
| first_task.a | 18.75 | 21.17 | 9 | first in run |
| first_task.b | 14.93 | 17.37 | 9 | second, A's lock, warm caches |

Phase timings (single commands; scopes differ by tool, see Setup scope; do not rank across tools):

| timing | outer p50 ms | outer p95 ms | inner p50 ms | inner p95 ms | ok/n |
|---|---|---|---|---|---|
| deps.first_checkout (single, outer) | 215.1 | | | | 1/1 |
| deps.second_checkout (single, outer) | 199.5 | | | | 1/1 |
| prepare.a (single, outer) | 26.4 | | | | 1/1 |
| prepare.b (single, outer) | 35.0 | | | | 1/1 |
| prepare.c (single, outer) | 32.0 | | | | 1/1 |
| prepare.d (single, outer) | 60.7 | | | | 1/1 |
| ready.a (single, outer) | 8651.3 | | | | 1/1 |
| ready.b (single, outer) | 9126.6 | | | | 1/1 |
| repeat.app_read | 628.934 | 676.348 | None | None | 20/20 |
| repeat.entry | 71.296 | 82.307 | None | None | 20/20 |
| setup.first_checkout (single, outer) | 5220.0 | | | | 1/1 |
| setup.second_checkout (single, outer) | 2590.0 | | | | 1/1 |

`ready.<co>` sums start, native readiness and the first verified identity (app deps excluded).
First-checkout timings start from the image's cache state above; they are not universal cold installs.
