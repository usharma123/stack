# GNU Guix 1.5.0 (channel 71d0101) (guix:default) run 20261006t175917-e3a5f2

valid: True · completed: True · transport: docker · isolation boundary: service-instance
measurement: blocked-prerequisite: no checks executed, no timings · reportable: False

BLOCKED (environment prerequisite, not a tool result): provision-guix-canary: guix-daemon could not set up its build sandbox in this container (see log above); --disable-chroot was not used; guix-daemon could not set up its build sandbox in this container (see log above); --disable-chroot was not used

Setup scope: not declared
Cache state: image caches not cleared; first-checkout timings may include preseeded caches

| check | status | mode | detail |
|---|---|---|---|
| provision | blocked | n/a | provision-guix-canary: guix-daemon could not set up its build sandbox in this container (see log above); --disable-chroot was not used; guix-daemon could not set up its build sandbox in this container |
| setup.a | blocked | n/a | not executed: provisioning blocked |
| lock.created | blocked | n/a | not executed: provisioning blocked |
| deps.a | blocked | n/a | not executed: provisioning blocked |
| start.a | blocked | n/a | not executed: provisioning blocked |
| migrate.a | blocked | n/a | not executed: provisioning blocked |
| crud_cache.a | blocked | n/a | not executed: provisioning blocked |
| tests.a | blocked | n/a | not executed: provisioning blocked |
| start.repeat | blocked | n/a | not executed: provisioning blocked |
| setup.b | blocked | n/a | not executed: provisioning blocked |
| deps.b | blocked | n/a | not executed: provisioning blocked |
| start.b | blocked | n/a | not executed: provisioning blocked |
| migrate.b | blocked | n/a | not executed: provisioning blocked |
| crud_cache.b | blocked | n/a | not executed: provisioning blocked |
| tests.b | blocked | n/a | not executed: provisioning blocked |
| isolation | blocked | n/a | not executed: provisioning blocked |
| repeat.entry | blocked | n/a | not executed: provisioning blocked |
| repeat.app_read | blocked | n/a | not executed: provisioning blocked |
| status | blocked | n/a | not executed: provisioning blocked |
| stop.a | blocked | n/a | not executed: provisioning blocked |
| b.survives | blocked | n/a | not executed: provisioning blocked |
| restart.a | blocked | n/a | not executed: provisioning blocked |
| persist.pg | blocked | n/a | not executed: provisioning blocked |
| persist.redis | blocked | n/a | not executed: provisioning blocked |
| cache.after_restart | blocked | n/a | not executed: provisioning blocked |
| lock.frozen_copy | blocked | n/a | not executed: provisioning blocked |
| bad_config | blocked | n/a | not executed: provisioning blocked |
| occupied_port | blocked | n/a | not executed: provisioning blocked |
| cleanup.processes | pass | scripted |  |
| cleanup.supervisors | observed | n/a | none |

No timings: the run is blocked or invalid. Raw command receipts remain in steps.jsonl.
