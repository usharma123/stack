# GitGrove 0.1.0-alpha.1.8 + Docker Compose (git-grove:default) run 20261006t180109-89ad03

valid: True · completed: True · transport: host · isolation boundary: container
measurement: diagnostic: timings recorded per check; only passing checks' samples count · reportable: False

Setup scope: tool-native worktree sync/config check plus scripted provider resolution (pinned CPython found by uv, committed uv.lock checked); dependencies install in the deps step, services start in the start step
Cache state: host Docker image cache and the run-private uv cache are not cleared; service images may already be present on the host

| check | status | mode | detail |
|---|---|---|---|
| setup.a | pass | scripted |  |
| lock.created | pass | scripted |  |
| deps.a | pass | native |  |
| start.a | pass | scripted | readiness=scripted pg=5432 redis=6379 |
| migrate.a | pass | native |  |
| crud_cache.a | pass | native |  |
| tests.a | pass | native |  |
| start.repeat | pass | scripted | start exit 0 |
| setup.b | pass | scripted |  |
| deps.b | pass | native |  |
| start.b | pass | scripted | readiness=scripted pg=5432 redis=6379 |
| migrate.b | pass | native |  |
| crud_cache.b | pass | native |  |
| tests.b | pass | native |  |
| isolation | pass | scripted | boundary=container |
| repeat.entry | pass | native |  |
| repeat.app_read | pass | native |  |
| status | observed | scripted | exit 0 |
| stop.a | pass | scripted | stop exit 0, probe exit 0, app after stop exit 1 |
| b.survives | pass | n/a |  |
| restart.a | pass | scripted | readiness=scripted pg=5432 redis=6379 |
| persist.pg | pass | native |  |
| persist.redis | pass | native | policy={'appendonly': 'yes', 'appendfsync': 'always', 'save': '3600 1 300 100 60 10000', 'dir': '/data'} |
| cache.after_restart | pass | native |  |
| lock.frozen_copy | pass | scripted | setup exit 0; lock unchanged; versions match |
| bad_config | blocked | scripted | setup exit 1: environment prerequisite failed before the intended refusal: ERROR: failed to build: failed to solve: error getting credentials - err: exit status 1, out: `` |
| occupied_port | pass | scripted | relocated |
| cleanup.processes | pass | scripted |  |
| cleanup.supervisors | observed | n/a | none |

End-to-end time to first verified work (setup, start, readiness, app deps, identity,
migrate, mark/CRUD/cache, pytest). `steps` sums those receipts; `wall` also includes
harness verification steps. This, not any single setup command, is the cross-tool task time.
It starts from an already PREPARED checkout; prepare (reported separately as prepare.<co>) covers: `git worktree add` at Grove's attach path (Grove attaches at start).

| task | steps s | wall s | receipts | checkout |
|---|---|---|---|---|
| first_task.a | 9.66 | 10.53 | 9 | first in run |
| first_task.b | 8.13 | 8.92 | 9 | second, A's lock, warm caches |

Phase timings (single commands; scopes differ by tool, see Setup scope; do not rank across tools):

| timing | outer p50 ms | outer p95 ms | inner p50 ms | inner p95 ms | ok/n |
|---|---|---|---|---|---|
| deps.first_checkout (single, outer) | 158.0 | | | | 1/1 |
| deps.second_checkout (single, outer) | 162.5 | | | | 1/1 |
| prepare.a (single, outer) | 184.2 | | | | 1/1 |
| prepare.b (single, outer) | 59.8 | | | | 1/1 |
| prepare.c (single, outer) | 74.4 | | | | 1/1 |
| prepare.d (single, outer) | 57.2 | | | | 1/1 |
| prepare.e (single, outer) | 68.2 | | | | 1/1 |
| ready.a (single, outer) | 3172.1 | | | | 1/1 |
| ready.b (single, outer) | 3714.5 | | | | 1/1 |
| repeat.app_read | 637.6 | 681.99 | None | None | 20/20 |
| repeat.entry | 109.905 | 120.493 | None | None | 20/20 |
| setup.first_checkout (single, outer) | 2367.0 | | | | 1/1 |
| setup.second_checkout (single, outer) | 1199.5 | | | | 1/1 |

`ready.<co>` sums start, native readiness and the first verified identity (app deps excluded).
First-checkout timings start from the image's cache state above; they are not universal cold installs.
