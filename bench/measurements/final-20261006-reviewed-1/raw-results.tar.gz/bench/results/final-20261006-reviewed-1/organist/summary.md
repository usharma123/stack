# Organist (organist:default) run 20261006t180558-6df6a6

valid: True · completed: True · transport: docker · isolation boundary: service-instance
measurement: diagnostic: timings recorded per check; only passing checks' samples count · reportable: False

Setup scope: flake lock + Organist's Nickel lock regeneration + realising the dev shell and the Honcho services app (all tool installation); services start in start()
Cache state: ev-nix image's Nix store as built; substitutes fetched in A are reused by B (same store)

| check | status | mode | detail |
|---|---|---|---|
| setup.a | pass | native |  |
| lock.created | pass | native |  |
| deps.a | pass | native |  |
| start.a | pass | native | readiness=scripted pg=25432 redis=26379 |
| migrate.a | pass | native |  |
| crud_cache.a | pass | native |  |
| tests.a | pass | native |  |
| start.repeat | pass | native | start exit 0 |
| setup.b | pass | native |  |
| deps.b | pass | native |  |
| start.b | pass | native | readiness=scripted pg=25433 redis=26380 |
| migrate.b | pass | native |  |
| crud_cache.b | pass | native |  |
| tests.b | pass | native |  |
| isolation | pass | scripted | boundary=service-instance |
| repeat.entry | pass | native |  |
| repeat.app_read | pass | native |  |
| status | observed | scripted | exit 0 |
| stop.a | pass | scripted | stop exit 0, probe exit 0, app after stop exit 3 |
| b.survives | pass | n/a |  |
| restart.a | pass | native | readiness=scripted pg=25432 redis=26379 |
| persist.pg | pass | native |  |
| persist.redis | pass | native | policy={'appendonly': 'yes', 'appendfsync': 'always', 'save': '3600 1 300 100 60 10000', 'dir': '/home/agent/rwb/a/.rwb-state/redis'} |
| cache.after_restart | pass | native |  |
| lock.frozen_copy | pass | native | setup exit 0; lock unchanged; versions match |
| bad_config | pass | native | setup exit 1 (intended diagnostic) |
| occupied_port | pass | scripted | refused-at-start |
| cleanup.processes | pass | scripted |  |
| cleanup.supervisors | observed | n/a | none |

End-to-end time to first verified work (setup, start, readiness, app deps, identity,
migrate, mark/CRUD/cache, pytest). `steps` sums those receipts; `wall` also includes
harness verification steps. This, not any single setup command, is the cross-tool task time.
It starts from an already PREPARED checkout; prepare (reported separately as prepare.<co>) covers: benchmark glue only: fixture + tool config copy, source token.

| task | steps s | wall s | receipts | checkout |
|---|---|---|---|---|
| first_task.a | 52.36 | 55.61 | 9 | first in run |
| first_task.b | 16.38 | 18.99 | 9 | second, A's lock, warm caches |

Phase timings (single commands; scopes differ by tool, see Setup scope; do not rank across tools):

| timing | outer p50 ms | outer p95 ms | inner p50 ms | inner p95 ms | ok/n |
|---|---|---|---|---|---|
| deps.first_checkout (single, outer) | 2384.5 | | | | 1/1 |
| deps.second_checkout (single, outer) | 1716.0 | | | | 1/1 |
| prepare.a (single, outer) | 97.4 | | | | 1/1 |
| prepare.b (single, outer) | 94.4 | | | | 1/1 |
| prepare.c (single, outer) | 83.4 | | | | 1/1 |
| prepare.d (single, outer) | 74.3 | | | | 1/1 |
| prepare.e (single, outer) | 77.8 | | | | 1/1 |
| ready.a (single, outer) | 2553.9 | | | | 1/1 |
| ready.b (single, outer) | 4436.7 | | | | 1/1 |
| repeat.app_read | 1308.313 | 1377.731 | 1250.357 | 1315.046 | 20/20 |
| repeat.entry | 1132.498 | 1226.317 | 1075.123 | 1166.649 | 20/20 |
| setup.first_checkout (single, outer) | 38192.6 | | | | 1/1 |
| setup.second_checkout (single, outer) | 3547.9 | | | | 1/1 |

`ready.<co>` sums start, native readiness and the first verified identity (app deps excluded).
First-checkout timings start from the image's cache state above; they are not universal cold installs.
