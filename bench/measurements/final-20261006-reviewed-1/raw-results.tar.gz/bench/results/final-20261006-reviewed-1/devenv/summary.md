# devenv (devenv:default) run 20261006t172749-4fe69b

valid: True · completed: True · transport: docker · isolation boundary: service-instance
measurement: diagnostic: timings recorded per check; only passing checks' samples count · reportable: False

Setup scope: first `devenv shell -- true`: resolves inputs into devenv.lock (A) and builds the shell with all packages; service init (initdb) happens at `devenv up`
Cache state: ev-devenv image (Determinate Nix 3.23.0, devenv 2.3.1 preinstalled): Nix store as built; the 2.4.0 CLI is provisioned untimed; A's substitutes are reused by B (same store)

| check | status | mode | detail |
|---|---|---|---|
| setup.a | pass | native |  |
| lock.created | pass | native |  |
| deps.a | pass | native |  |
| start.a | pass | native | readiness=native pg=55432 redis=56379 |
| migrate.a | pass | native |  |
| crud_cache.a | pass | native |  |
| tests.a | pass | native |  |
| start.repeat | pass | native | start exit 0 |
| setup.b | pass | native |  |
| deps.b | pass | native |  |
| start.b | pass | native | readiness=native pg=55433 redis=56380 |
| migrate.b | pass | native |  |
| crud_cache.b | pass | native |  |
| tests.b | pass | native |  |
| isolation | pass | native | boundary=service-instance |
| repeat.entry | pass | native |  |
| repeat.app_read | pass | native |  |
| status | observed | n/a | exit 0 |
| stop.a | pass | native | stop exit 0, probe exit 0, app after stop exit 3 |
| b.survives | pass | n/a |  |
| restart.a | pass | native | readiness=native pg=55432 redis=56379 |
| persist.pg | pass | native |  |
| persist.redis | pass | native | policy={'appendonly': 'yes', 'appendfsync': 'always', 'save': '3600 1 300 100 60 10000', 'dir': '/home/agent/rwb/a/.devenv/state/redis'} |
| cache.after_restart | pass | native |  |
| lock.frozen_copy | pass | n/a | setup exit 0; lock unchanged; versions match; executable paths differ (observed) |
| bad_config | pass | native | setup exit 1 (intended diagnostic) |
| occupied_port | pass | native | relocated |
| cleanup.processes | pass | native |  |
| cleanup.supervisors | observed | n/a | none |

End-to-end time to first verified work (setup, start, readiness, app deps, identity,
migrate, mark/CRUD/cache, pytest). `steps` sums those receipts; `wall` also includes
harness verification steps. This, not any single setup command, is the cross-tool task time.
It starts from an already PREPARED checkout; prepare (reported separately as prepare.<co>) covers: benchmark glue only: fixture + tool config copy, source token.

| task | steps s | wall s | receipts | checkout |
|---|---|---|---|---|
| first_task.a | 25.28 | 25.68 | 10 | first in run |
| first_task.b | 13.26 | 13.61 | 10 | second, A's lock, warm caches |

Phase timings (single commands; scopes differ by tool, see Setup scope; do not rank across tools):

| timing | outer p50 ms | outer p95 ms | inner p50 ms | inner p95 ms | ok/n |
|---|---|---|---|---|---|
| deps.first_checkout (single, outer) | 2123.8 | | | | 1/1 |
| deps.second_checkout (single, outer) | 2236.9 | | | | 1/1 |
| prepare.a (single, outer) | 73.5 | | | | 1/1 |
| prepare.b (single, outer) | 62.8 | | | | 1/1 |
| prepare.c (single, outer) | 64.0 | | | | 1/1 |
| prepare.d (single, outer) | 62.1 | | | | 1/1 |
| prepare.e (single, outer) | 64.2 | | | | 1/1 |
| ready.a (single, outer) | 2574.3 | | | | 1/1 |
| ready.b (single, outer) | 5678.2 | | | | 1/1 |
| repeat.app_read | 235.787 | 367.231 | 177.867 | 306.533 | 20/20 |
| repeat.entry | 101.634 | 110.878 | 47.585 | 49.364 | 20/20 |
| setup.first_checkout (single, outer) | 17041.4 | | | | 1/1 |
| setup.second_checkout (single, outer) | 3944.7 | | | | 1/1 |

`ready.<co>` sums start, native readiness and the first verified identity (app deps excluded).
First-checkout timings start from the image's cache state above; they are not universal cold installs.
