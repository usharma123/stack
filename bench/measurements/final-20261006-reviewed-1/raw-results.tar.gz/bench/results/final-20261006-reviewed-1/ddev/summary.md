# DDEV (ddev:default) run 20261006t173718-c83372

valid: True · completed: True · transport: host · isolation boundary: container
measurement: diagnostic: timings recorded per check; only passing checks' samples count · reportable: False

Setup scope: ddev utility download-images: renders the project and pulls its images; builds and the app's uv sync happen at start/deps
Cache state: host Docker image cache and the pinned CLI download are reused across runs; A pulls/builds only images missing from the host cache, B reuses A's

| check | status | mode | detail |
|---|---|---|---|
| setup.a | fail | scripted | exit 1 |
| cleanup.processes | pass | native |  |
| cleanup.supervisors | observed | n/a | none |

Phase timings (single commands; scopes differ by tool, see Setup scope; do not rank across tools):

| timing | outer p50 ms | outer p95 ms | inner p50 ms | inner p95 ms | ok/n |
|---|---|---|---|---|---|
| prepare.a (single, outer) | 31.7 | | | | 1/1 |

`ready.<co>` sums start, native readiness and the first verified identity (app deps excluded).
First-checkout timings start from the image's cache state above; they are not universal cold installs.
