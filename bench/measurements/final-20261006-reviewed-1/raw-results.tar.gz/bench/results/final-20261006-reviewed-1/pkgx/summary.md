# pkgx 2.11.0 + dev 1.8.1 (pkgx:default) run 20261006t174747-157710

valid: True · completed: True · transport: docker · isolation boundary: service-instance
measurement: diagnostic: timings recorded per check; only passing checks' samples count · reportable: False

Setup scope: not declared
Cache state: image caches not cleared; first-checkout timings may include preseeded caches

| check | status | mode | detail |
|---|---|---|---|
| setup.a | pass | n/a |  |
| lock.created | unsupported | n/a | adapter declares no lock files |
| deps.a | pass | native |  |
| start.a | pass | scripted | readiness=scripted pg=25432 redis=26379 |
| migrate.a | pass | native |  |
| crud_cache.a | pass | native |  |
| tests.a | pass | native |  |
| start.repeat | pass | scripted | start exit 0 |
| setup.b | pass | n/a |  |
| deps.b | pass | native |  |
| start.b | pass | scripted | readiness=scripted pg=25433 redis=26380 |
| migrate.b | pass | native |  |
| crud_cache.b | pass | native |  |
| tests.b | pass | native |  |
| isolation | pass | scripted | boundary=service-instance |
| repeat.entry | pass | native |  |
| repeat.app_read | pass | native |  |
| status | observed | scripted | exit 0 |
| stop.a | pass | scripted | stop exit 0, probe exit 0, app after stop exit 3 |
| b.survives | pass | n/a |  |
| restart.a | pass | scripted | readiness=scripted pg=25432 redis=26379 |
| persist.pg | pass | native |  |
| persist.redis | pass | native | policy={'appendonly': 'yes', 'appendfsync': 'always', 'save': '3600 1 300 100 60 10000', 'dir': '/home/agent/rwb/a/.rwb-state/redis'} |
| cache.after_restart | pass | native |  |
| lock.frozen_copy | unsupported | n/a | no frozen/locked setup mode |
| bad_config | pass | n/a | setup exit 1 (intended diagnostic) |
| occupied_port | pass | scripted | refused-at-start |
| cleanup.processes | pass | scripted |  |
| cleanup.supervisors | observed | n/a | none |

End-to-end time to first verified work (setup, start, readiness, app deps, identity,
migrate, mark/CRUD/cache, pytest). `steps` sums those receipts; `wall` also includes
harness verification steps. This, not any single setup command, is the cross-tool task time.
It starts from an already PREPARED checkout; prepare (reported separately as prepare.<co>) covers: benchmark glue only: fixture + tool config copy, source token.

| task | steps s | wall s | receipts | checkout |
|---|---|---|---|---|
| first_task.a | 11.79 | 12.2 | 9 | first in run |
| first_task.b | 3.66 | 4.08 | 9 | second, A's lock, warm caches |

Phase timings (single commands; scopes differ by tool, see Setup scope; do not rank across tools):

| timing | outer p50 ms | outer p95 ms | inner p50 ms | inner p95 ms | ok/n |
|---|---|---|---|---|---|
| deps.first_checkout (single, outer) | 715.0 | | | | 1/1 |
| deps.second_checkout (single, outer) | 198.3 | | | | 1/1 |
| prepare.a (single, outer) | 88.1 | | | | 1/1 |
| prepare.b (single, outer) | 70.2 | | | | 1/1 |
| prepare.d (single, outer) | 73.8 | | | | 1/1 |
| prepare.e (single, outer) | 69.4 | | | | 1/1 |
| ready.a (single, outer) | 508.4 | | | | 1/1 |
| ready.b (single, outer) | 1811.8 | | | | 1/1 |
| repeat.app_read | 260.317 | 350.973 | 199.312 | 232.143 | 20/20 |
| repeat.entry | 136.772 | 144.844 | 71.301 | 82.023 | 20/20 |
| setup.first_checkout (single, outer) | 6996.8 | | | | 1/1 |
| setup.second_checkout (single, outer) | 140.2 | | | | 1/1 |

`ready.<co>` sums start, native readiness and the first verified identity (app deps excluded).
First-checkout timings start from the image's cache state above; they are not universal cold installs.
