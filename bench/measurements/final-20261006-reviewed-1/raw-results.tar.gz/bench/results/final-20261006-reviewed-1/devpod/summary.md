# DevPod (Docker provider) (devpod:default) run 20261006t173510-1b1b4e

valid: True · completed: True · transport: host · isolation boundary: container
measurement: diagnostic: timings recorded per check; only passing checks' samples count · reportable: False

Setup scope: Compose model validation only; DevPod builds/pulls images, injects its agent and runs uv sync (postCreateCommand) in `up`
Cache state: host Docker image cache and the pinned CLI download are reused across runs; A pulls/builds only images missing from the host cache, B reuses A's

| check | status | mode | detail |
|---|---|---|---|
| setup.a | pass | scripted |  |
| lock.created | pass | scripted |  |
| deps.a | pass | native |  |
| start.a | pass | native | readiness=native pg=5432 redis=6379 |
| migrate.a | pass | native |  |
| crud_cache.a | pass | native |  |
| tests.a | pass | native |  |
| start.repeat | pass | native | start exit 0 |
| setup.b | pass | scripted |  |
| deps.b | pass | native |  |
| start.b | pass | native | readiness=native pg=5432 redis=6379 |
| migrate.b | pass | native |  |
| crud_cache.b | pass | native |  |
| tests.b | pass | native |  |
| isolation | pass | native | boundary=container |
| repeat.entry | pass | native |  |
| repeat.app_read | pass | native |  |
| status | observed | native | exit 0 |
| stop.a | pass | native | stop exit 0, probe exit 0, after-stop entry not run (entry auto-resumes the project) |
| b.survives | pass | n/a |  |
| restart.a | pass | native | readiness=native pg=5432 redis=6379 |
| persist.pg | pass | native |  |
| persist.redis | pass | native | policy={'appendonly': 'yes', 'appendfsync': 'always', 'save': '3600 1 300 100 60 10000', 'dir': '/data'} |
| cache.after_restart | pass | native |  |
| lock.frozen_copy | pass | scripted | setup exit 0; lock unchanged; versions match |
| bad_config | blocked | scripted | setup exit 0, start exit 1: environment prerequisite failed before the intended refusal: 13:37:08 info devcontainer up: start container: build and extend docker-compose: inspect image python:3.13.99-s |
| occupied_port | not_applicable | n/a | no host port is published for PostgreSQL/Redis; each checkout uses internal ports on its own Compose network, so a host listener cannot collide |
| cleanup.processes | pass | native |  |
| cleanup.supervisors | observed | n/a | none |

End-to-end time to first verified work (setup, start, readiness, app deps, identity,
migrate, mark/CRUD/cache, pytest). `steps` sums those receipts; `wall` also includes
harness verification steps. This, not any single setup command, is the cross-tool task time.
It starts from an already PREPARED checkout; prepare (reported separately as prepare.<co>) covers: benchmark glue only: fixture + tool config copy, source token.

| task | steps s | wall s | receipts | checkout |
|---|---|---|---|---|
| first_task.a | 16.83 | 19.19 | 9 | first in run |
| first_task.b | 16.94 | 19.41 | 9 | second, A's lock, warm caches |

Phase timings (single commands; scopes differ by tool, see Setup scope; do not rank across tools):

| timing | outer p50 ms | outer p95 ms | inner p50 ms | inner p95 ms | ok/n |
|---|---|---|---|---|---|
| deps.first_checkout (single, outer) | 1028.0 | | | | 1/1 |
| deps.second_checkout (single, outer) | 1032.0 | | | | 1/1 |
| prepare.a (single, outer) | 36.2 | | | | 1/1 |
| prepare.b (single, outer) | 38.2 | | | | 1/1 |
| prepare.c (single, outer) | 47.0 | | | | 1/1 |
| prepare.d (single, outer) | 46.6 | | | | 1/1 |
| ready.a (single, outer) | 4668.9 | | | | 1/1 |
| ready.b (single, outer) | 8631.9 | | | | 1/1 |
| repeat.app_read | 1436.507 | 1674.465 | None | None | 20/20 |
| repeat.entry | 781.406 | 1010.087 | None | None | 20/20 |
| setup.first_checkout (single, outer) | 63.0 | | | | 1/1 |
| setup.second_checkout (single, outer) | 157.6 | | | | 1/1 |

`ready.<co>` sums start, native readiness and the first verified identity (app deps excluded).
First-checkout timings start from the image's cache state above; they are not universal cold installs.
