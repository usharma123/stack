# mise + Pitchfork (mise:default) run 20261006t171958-c79567

valid: True · completed: True · transport: docker · isolation boundary: service-instance
measurement: diagnostic: timings recorded per check; only passing checks' samples count · reportable: False

Setup scope: mise lock (A only) + `mise install --locked`: installs every tool and server binary
Cache state: fresh ev-base container: no mise cache; A downloads, B reuses (same container)

| check | status | mode | detail |
|---|---|---|---|
| setup.a | pass | native |  |
| lock.created | pass | native |  |
| deps.a | pass | native |  |
| start.a | pass | native | readiness=native pg=25432 redis=26379 |
| migrate.a | pass | native |  |
| crud_cache.a | pass | native |  |
| tests.a | pass | native |  |
| start.repeat | pass | native | start exit 0 |
| setup.b | pass | native |  |
| deps.b | pass | native |  |
| start.b | pass | native | readiness=native pg=25433 redis=26380 |
| migrate.b | pass | native |  |
| crud_cache.b | pass | native |  |
| tests.b | pass | native |  |
| isolation | pass | native | boundary=service-instance |
| repeat.entry | pass | native |  |
| repeat.app_read | pass | native |  |
| status | observed | native | exit 0 |
| stop.a | pass | native | stop exit 0, probe exit 0, app after stop exit 3 |
| b.survives | pass | n/a |  |
| restart.a | pass | native | readiness=native pg=25432 redis=26379 |
| persist.pg | pass | native |  |
| persist.redis | pass | native | policy={'appendonly': 'yes', 'appendfsync': 'everysec', 'save': '3600 1 300 100 60 10000', 'dir': '/home/agent/rwb/a/.data/redis'} |
| cache.after_restart | pass | native |  |
| lock.frozen_copy | pass | native | setup exit 0; lock unchanged; versions match |
| bad_config | blocked | native | setup exit 1: failure output lacks the intended diagnostic /99\.99\.99/postgresql_99/ |
| occupied_port | pass | native | refused-at-start |
| cleanup.processes | pass | native |  |
| cleanup.supervisors | observed | n/a | /home/agent/.local/share/mise/installs/pitchfork/2.29.0/pitchfork supervisor run |

End-to-end time to first verified work (setup, start, readiness, app deps, identity,
migrate, mark/CRUD/cache, pytest). `steps` sums those receipts; `wall` also includes
harness verification steps. This, not any single setup command, is the cross-tool task time.
It starts from an already PREPARED checkout; prepare (reported separately as prepare.<co>) covers: benchmark glue only: fixture + tool config copy, source token.

| task | steps s | wall s | receipts | checkout |
|---|---|---|---|---|
| first_task.a | 10.41 | 10.7 | 9 | first in run |
| first_task.b | 3.57 | 3.83 | 9 | second, A's lock, warm caches |

Phase timings (single commands; scopes differ by tool, see Setup scope; do not rank across tools):

| timing | outer p50 ms | outer p95 ms | inner p50 ms | inner p95 ms | ok/n |
|---|---|---|---|---|---|
| deps.first_checkout (single, outer) | 532.1 | | | | 1/1 |
| deps.second_checkout (single, outer) | 135.6 | | | | 1/1 |
| prepare.a (single, outer) | 68.5 | | | | 1/1 |
| prepare.b (single, outer) | 94.1 | | | | 1/1 |
| prepare.c (single, outer) | 67.0 | | | | 1/1 |
| prepare.d (single, outer) | 71.4 | | | | 1/1 |
| prepare.e (single, outer) | 84.2 | | | | 1/1 |
| ready.a (single, outer) | 816.6 | | | | 1/1 |
| ready.b (single, outer) | 2107.3 | | | | 1/1 |
| repeat.app_read | 195.845 | 255.729 | 132.651 | 178.089 | 20/20 |
| repeat.entry | 73.548 | 111.284 | 9.726 | 16.448 | 20/20 |
| setup.first_checkout (single, outer) | 5779.9 | | | | 1/1 |
| setup.second_checkout (single, outer) | 110.4 | | | | 1/1 |

`ready.<co>` sums start, native readiness and the first verified identity (app deps excluded).
First-checkout timings start from the image's cache state above; they are not universal cold installs.
