# Vagrant (Docker provider) (vagrant:default) run 20261006t180848-312625

valid: True · completed: True · transport: host · isolation boundary: container
measurement: diagnostic: timings recorded per check; only passing checks' samples count · reportable: False

Setup scope: `vagrant validate` only; network/volume creation, image pulls, the toolchain image build and container creation happen in `vagrant up` (start)
Cache state: host Docker image/build cache not cleared; uv cache is run-owned and shared by the run's checkouts (A fills it, B is warm)

| check | status | mode | detail |
|---|---|---|---|
| setup.a | pass | n/a |  |
| lock.created | unsupported | n/a | adapter declares no lock files |
| deps.a | pass | native |  |
| start.a | pass | native | readiness=scripted pg=5432 redis=6379 |
| migrate.a | pass | native |  |
| crud_cache.a | pass | native |  |
| tests.a | pass | native |  |
| start.repeat | pass | native | start exit 0 |
| setup.b | pass | n/a |  |
| deps.b | pass | native |  |
| start.b | pass | native | readiness=scripted pg=5432 redis=6379 |
| migrate.b | pass | native |  |
| crud_cache.b | pass | native |  |
| tests.b | pass | native |  |
| isolation | pass | scripted | boundary=container |
| repeat.entry | pass | native |  |
| repeat.app_read | pass | native |  |
| status | observed | native | exit 0 |
| stop.a | pass | native | stop exit 0, probe exit 0, app after stop exit 1 |
| b.survives | pass | n/a |  |
| restart.a | pass | native | readiness=scripted pg=5432 redis=6379 |
| persist.pg | pass | native |  |
| persist.redis | pass | native | policy={'appendonly': 'yes', 'appendfsync': 'always', 'save': '3600 1 300 100 60 10000', 'dir': '/data'} |
| cache.after_restart | pass | native |  |
| lock.frozen_copy | unsupported | n/a | no frozen/locked setup mode |
| bad_config | blocked | n/a | setup exit 0, start exit 1: environment prerequisite failed before the intended refusal: docker: error getting credentials - err: exit status 1, out: `` |
| occupied_port | not_applicable | n/a | services publish no host ports; each checkout reaches pg:5432 and redis:6379 on its own Docker network |
| cleanup.processes | pass | native |  |
| cleanup.supervisors | observed | n/a | none |

End-to-end time to first verified work (setup, start, readiness, app deps, identity,
migrate, mark/CRUD/cache, pytest). `steps` sums those receipts; `wall` also includes
harness verification steps. This, not any single setup command, is the cross-tool task time.
It starts from an already PREPARED checkout; prepare (reported separately as prepare.<co>) covers: benchmark glue only: fixture + tool config copy, source token.

| task | steps s | wall s | receipts | checkout |
|---|---|---|---|---|
| first_task.a | 35.97 | 47.79 | 9 | first in run |
| first_task.b | 30.48 | 39.42 | 9 | second, A's lock, warm caches |

Phase timings (single commands; scopes differ by tool, see Setup scope; do not rank across tools):

| timing | outer p50 ms | outer p95 ms | inner p50 ms | inner p95 ms | ok/n |
|---|---|---|---|---|---|
| deps.first_checkout (single, outer) | 4140.4 | | | | 1/1 |
| deps.second_checkout (single, outer) | 2991.6 | | | | 1/1 |
| prepare.a (single, outer) | 38.9 | | | | 1/1 |
| prepare.b (single, outer) | 37.9 | | | | 1/1 |
| prepare.d (single, outer) | 87.9 | | | | 1/1 |
| ready.a (single, outer) | 11812.8 | | | | 1/1 |
| ready.b (single, outer) | 12271.7 | | | | 1/1 |
| repeat.app_read | 2516.719 | 3115.045 | None | None | 20/20 |
| repeat.entry | 2456.605 | 2667.259 | None | None | 20/20 |
| setup.first_checkout (single, outer) | 4795.4 | | | | 1/1 |
| setup.second_checkout (single, outer) | 1813.1 | | | | 1/1 |

`ready.<co>` sums start, native readiness and the first verified identity (app deps excluded).
First-checkout timings start from the image's cache state above; they are not universal cold installs.
