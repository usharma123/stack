# Devbox (devbox:default) run 20261006t172345-ef5197

valid: True · completed: True · transport: docker · isolation boundary: service-instance
measurement: diagnostic: timings recorded per check; only passing checks' samples count · reportable: False

Setup scope: `devbox install`: resolves/locks (A) and realises packages; plugin init and initdb run at start
Cache state: ev-devbox image: its Nix store may already hold some packages (preseeded at image build)

| check | status | mode | detail |
|---|---|---|---|
| setup.a | pass | native |  |
| lock.created | pass | native |  |
| deps.a | pass | native |  |
| start.a | pass | native | readiness=scripted pg=25432 redis=26379 |
| migrate.a | pass | native |  |
| crud_cache.a | pass | native |  |
| tests.a | pass | native |  |
| start.repeat | pass | native | start exit 0 |
| setup.b | pass | native |  |
| deps.b | pass | native |  |
| start.b | pass | native | readiness=scripted pg=25433 redis=26380 |
| migrate.b | pass | native |  |
| crud_cache.b | pass | native |  |
| tests.b | pass | native |  |
| isolation | pass | native | boundary=service-instance |
| repeat.entry | pass | native |  |
| repeat.app_read | pass | native |  |
| status | observed | n/a | exit 0 |
| stop.a | pass | scripted | stop exit 0, probe exit 0, app after stop exit 3 |
| b.survives | pass | n/a |  |
| restart.a | pass | native | readiness=scripted pg=25432 redis=26379 |
| persist.pg | pass | native |  |
| persist.redis | pass | native | policy={'appendonly': 'no', 'appendfsync': 'everysec', 'save': '900 1 300 10 60 10000', 'dir': '/home/agent/rwb/a/.devbox/virtenv/redis'} |
| cache.after_restart | pass | native |  |
| lock.frozen_copy | pass | n/a | setup exit 0; lock unchanged; versions match |
| bad_config | pass | native | setup exit 1 (intended diagnostic) |
| occupied_port | pass | scripted | detected-at-readiness |
| cleanup.processes | pass | scripted |  |
| cleanup.supervisors | observed | n/a | none |

End-to-end time to first verified work (setup, start, readiness, app deps, identity,
migrate, mark/CRUD/cache, pytest). `steps` sums those receipts; `wall` also includes
harness verification steps. This, not any single setup command, is the cross-tool task time.
It starts from an already PREPARED checkout; prepare (reported separately as prepare.<co>) covers: benchmark glue only: fixture + tool config copy, source token.

| task | steps s | wall s | receipts | checkout |
|---|---|---|---|---|
| first_task.a | 71.17 | 71.86 | 9 | first in run |
| first_task.b | 6.98 | 7.67 | 9 | second, A's lock, warm caches |

Phase timings (single commands; scopes differ by tool, see Setup scope; do not rank across tools):

| timing | outer p50 ms | outer p95 ms | inner p50 ms | inner p95 ms | ok/n |
|---|---|---|---|---|---|
| deps.first_checkout (single, outer) | 846.5 | | | | 1/1 |
| deps.second_checkout (single, outer) | 215.2 | | | | 1/1 |
| prepare.a (single, outer) | 75.4 | | | | 1/1 |
| prepare.b (single, outer) | 89.8 | | | | 1/1 |
| prepare.c (single, outer) | 84.3 | | | | 1/1 |
| prepare.d (single, outer) | 72.9 | | | | 1/1 |
| prepare.e (single, outer) | 70.6 | | | | 1/1 |
| ready.a (single, outer) | 435.6 | | | | 1/1 |
| ready.b (single, outer) | 3811.5 | | | | 1/1 |
| repeat.app_read | 238.773 | 298.21 | 175.559 | 243.728 | 20/20 |
| repeat.entry | 117.768 | 286.232 | 53.055 | 224.952 | 20/20 |
| setup.first_checkout (single, outer) | 62821.5 | | | | 1/1 |
| setup.second_checkout (single, outer) | 1497.0 | | | | 1/1 |

`ready.<co>` sums start, native readiness and the first verified identity (app deps excluded).
First-checkout timings start from the image's cache state above; they are not universal cold installs.
