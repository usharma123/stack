# workz 0.11.0 + uv + Docker Compose (workz:default) run 20261006t175943-16c496

valid: True · completed: True · transport: host · isolation boundary: container
measurement: diagnostic: timings recorded per check; only passing checks' samples count · reportable: False

Setup scope: tool-native worktree sync/config check plus scripted provider resolution (pinned CPython found by uv, committed uv.lock checked); dependencies install in the deps step, services start in the start step
Cache state: host Docker image cache and the run-private uv cache are not cleared; service images may already be present on the host

| check | status | mode | detail |
|---|---|---|---|
| setup.a | pass | scripted |  |
| lock.created | pass | scripted |  |
| deps.a | pass | native |  |
| start.a | pass | scripted | readiness=scripted pg=5432 redis=6379 |
| migrate.a | pass | native |  |
| crud_cache.a | pass | native |  |
| tests.a | pass | native |  |
| start.repeat | pass | scripted | start exit 0 |
| setup.b | pass | scripted |  |
| deps.b | pass | native |  |
| start.b | pass | scripted | readiness=scripted pg=5432 redis=6379 |
| migrate.b | pass | native |  |
| crud_cache.b | pass | native |  |
| tests.b | pass | native |  |
| isolation | pass | scripted | boundary=container |
| repeat.entry | pass | native |  |
| repeat.app_read | pass | native |  |
| status | observed | scripted | exit 0 |
| stop.a | pass | scripted | stop exit 0, probe exit 0, app after stop exit 3 |
| b.survives | pass | n/a |  |
| restart.a | pass | scripted | readiness=scripted pg=5432 redis=6379 |
| persist.pg | pass | native |  |
| persist.redis | pass | native | policy={'appendonly': 'yes', 'appendfsync': 'always', 'save': '3600 1 300 100 60 10000', 'dir': '/data'} |
| cache.after_restart | pass | native |  |
| lock.frozen_copy | pass | scripted | setup exit 0; lock unchanged; versions match |
| bad_config | pass | scripted | setup exit 2 (intended diagnostic) |
| occupied_port | pass | scripted | refused-at-start |
| cleanup.processes | pass | scripted |  |
| cleanup.supervisors | observed | n/a | none |

End-to-end time to first verified work (setup, start, readiness, app deps, identity,
migrate, mark/CRUD/cache, pytest). `steps` sums those receipts; `wall` also includes
harness verification steps. This, not any single setup command, is the cross-tool task time.
It starts from an already PREPARED checkout; prepare (reported separately as prepare.<co>) covers: native `workz start --isolated --no-sync` worktree creation (excluded from first_task).

| task | steps s | wall s | receipts | checkout |
|---|---|---|---|---|
| first_task.a | 8.36 | 9.09 | 9 | first in run |
| first_task.b | 5.98 | 6.48 | 9 | second, A's lock, warm caches |

Phase timings (single commands; scopes differ by tool, see Setup scope; do not rank across tools):

| timing | outer p50 ms | outer p95 ms | inner p50 ms | inner p95 ms | ok/n |
|---|---|---|---|---|---|
| deps.first_checkout (single, outer) | 575.2 | | | | 1/1 |
| deps.second_checkout (single, outer) | 58.1 | | | | 1/1 |
| prepare.a (single, outer) | 625.7 | | | | 1/1 |
| prepare.b (single, outer) | 203.0 | | | | 1/1 |
| prepare.c (single, outer) | 217.2 | | | | 1/1 |
| prepare.d (single, outer) | 228.2 | | | | 1/1 |
| prepare.e (single, outer) | 223.6 | | | | 1/1 |
| ready.a (single, outer) | 1980.9 | | | | 1/1 |
| ready.b (single, outer) | 4065.7 | | | | 1/1 |
| repeat.app_read | 181.461 | 203.449 | None | None | 20/20 |
| repeat.entry | 21.108 | 23.113 | None | None | 20/20 |
| setup.first_checkout (single, outer) | 185.4 | | | | 1/1 |
| setup.second_checkout (single, outer) | 128.6 | | | | 1/1 |

`ready.<co>` sums start, native readiness and the first verified identity (app deps excluded).
First-checkout timings start from the image's cache state above; they are not universal cold installs.
