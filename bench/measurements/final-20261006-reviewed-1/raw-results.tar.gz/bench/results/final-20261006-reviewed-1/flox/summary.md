# Flox (flox:default) run 20261006t172032-28a7b7

valid: True · completed: True · transport: docker · isolation boundary: service-instance
measurement: diagnostic: timings recorded per check; only passing checks' samples count · reportable: False

Setup scope: first `flox activate -- true`: locks the manifest (A) and realises the environment
Cache state: ev-flox image: its Nix store may already hold some packages (preseeded at image build)

| check | status | mode | detail |
|---|---|---|---|
| setup.a | pass | native |  |
| lock.created | pass | native |  |
| deps.a | pass | native |  |
| start.a | pass | native | readiness=scripted pg=25432 redis=26379 |
| migrate.a | pass | native |  |
| crud_cache.a | pass | native |  |
| tests.a | pass | native |  |
| start.repeat | pass | native | start exit 0 |
| setup.b | pass | native |  |
| deps.b | pass | native |  |
| start.b | pass | native | readiness=scripted pg=25433 redis=26380 |
| migrate.b | pass | native |  |
| crud_cache.b | pass | native |  |
| tests.b | pass | native |  |
| isolation | pass | native | boundary=service-instance |
| repeat.entry | pass | native |  |
| repeat.app_read | pass | native |  |
| status | observed | native | exit 0 |
| stop.a | pass | native | stop exit 0, probe exit 0, app after stop exit 3 |
| b.survives | pass | n/a |  |
| restart.a | pass | native | readiness=scripted pg=25432 redis=26379 |
| persist.pg | pass | native |  |
| persist.redis | pass | native | policy={'appendonly': 'yes', 'appendfsync': 'always', 'save': '', 'dir': '/home/agent/rwb/a/.flox/cache/redis'} |
| cache.after_restart | pass | native |  |
| lock.frozen_copy | pass | n/a | setup exit 0; lock unchanged; versions match; executable paths differ (observed) |
| bad_config | pass | native | setup exit 1 (intended diagnostic) |
| occupied_port | pass | scripted | detected-at-readiness |
| cleanup.processes | pass | native |  |
| cleanup.supervisors | observed | n/a | none |

End-to-end time to first verified work (setup, start, readiness, app deps, identity,
migrate, mark/CRUD/cache, pytest). `steps` sums those receipts; `wall` also includes
harness verification steps. This, not any single setup command, is the cross-tool task time.
It starts from an already PREPARED checkout; prepare (reported separately as prepare.<co>) covers: benchmark glue only: fixture + tool config copy, source token.

| task | steps s | wall s | receipts | checkout |
|---|---|---|---|---|
| first_task.a | 35.67 | 36.13 | 9 | first in run |
| first_task.b | 6.05 | 6.35 | 9 | second, A's lock, warm caches |

Phase timings (single commands; scopes differ by tool, see Setup scope; do not rank across tools):

| timing | outer p50 ms | outer p95 ms | inner p50 ms | inner p95 ms | ok/n |
|---|---|---|---|---|---|
| deps.first_checkout (single, outer) | 562.7 | | | | 1/1 |
| deps.second_checkout (single, outer) | 253.9 | | | | 1/1 |
| prepare.a (single, outer) | 159.7 | | | | 1/1 |
| prepare.b (single, outer) | 111.3 | | | | 1/1 |
| prepare.c (single, outer) | 100.5 | | | | 1/1 |
| prepare.d (single, outer) | 91.2 | | | | 1/1 |
| prepare.e (single, outer) | 99.2 | | | | 1/1 |
| ready.a (single, outer) | 396.0 | | | | 1/1 |
| ready.b (single, outer) | 1619.3 | | | | 1/1 |
| repeat.app_read | 210.869 | 247.051 | 149.775 | 178.741 | 20/20 |
| repeat.entry | 74.993 | 97.757 | 18.529 | 22.301 | 20/20 |
| setup.first_checkout (single, outer) | 32139.4 | | | | 1/1 |
| setup.second_checkout (single, outer) | 2861.2 | | | | 1/1 |

`ready.<co>` sums start, native readiness and the first verified identity (app deps excluded).
First-checkout timings start from the image's cache state above; they are not universal cold installs.
