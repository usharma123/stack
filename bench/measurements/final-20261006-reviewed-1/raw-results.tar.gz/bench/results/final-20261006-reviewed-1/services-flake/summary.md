# services-flake (process-compose-flake) (services-flake:default) run 20261006t174332-f5a4e8

valid: True · completed: True · transport: docker · isolation boundary: service-instance
measurement: diagnostic: timings recorded per check; only passing checks' samples count · reportable: False

Setup scope: not declared
Cache state: image caches not cleared; first-checkout timings may include preseeded caches

| check | status | mode | detail |
|---|---|---|---|
| setup.a | pass | native |  |
| lock.created | pass | native |  |
| deps.a | pass | native |  |
| start.a | pass | native | readiness=native pg=25432 redis=26379 |
| migrate.a | pass | native |  |
| crud_cache.a | pass | native |  |
| tests.a | pass | native |  |
| start.repeat | pass | native | start exit 0 |
| setup.b | pass | native |  |
| deps.b | pass | native |  |
| start.b | pass | native | readiness=native pg=25433 redis=26380 |
| migrate.b | pass | native |  |
| crud_cache.b | pass | native |  |
| tests.b | pass | native |  |
| isolation | pass | native | boundary=service-instance |
| repeat.entry | pass | native |  |
| repeat.app_read | pass | native |  |
| status | observed | native | exit 0 |
| stop.a | pass | scripted | stop exit 0, probe exit 0, app after stop exit 3 |
| b.survives | pass | n/a |  |
| restart.a | pass | native | readiness=native pg=25432 redis=26379 |
| persist.pg | pass | native |  |
| persist.redis | pass | native | policy={'appendonly': 'yes', 'appendfsync': 'always', 'save': '3600 1 300 100 60 10000', 'dir': '/home/agent/rwb/a/.rwb-state/sf/redis'} |
| cache.after_restart | pass | native |  |
| lock.frozen_copy | pass | native | setup exit 0; lock unchanged; versions match; executable paths differ (observed) |
| bad_config | pass | native | setup exit 1 (intended diagnostic) |
| occupied_port | fail | native | readiness-infra-fault (exit 124) |
| cleanup.processes | pass | scripted |  |
| cleanup.supervisors | observed | n/a | none |

End-to-end time to first verified work (setup, start, readiness, app deps, identity,
migrate, mark/CRUD/cache, pytest). `steps` sums those receipts; `wall` also includes
harness verification steps. This, not any single setup command, is the cross-tool task time.
It starts from an already PREPARED checkout; prepare (reported separately as prepare.<co>) covers: benchmark glue only: fixture + tool config copy, source token.

| task | steps s | wall s | receipts | checkout |
|---|---|---|---|---|
| first_task.a | 33.15 | 35.49 | 10 | first in run |
| first_task.b | 15.59 | 18.28 | 10 | second, A's lock, warm caches |

Phase timings (single commands; scopes differ by tool, see Setup scope; do not rank across tools):

| timing | outer p50 ms | outer p95 ms | inner p50 ms | inner p95 ms | ok/n |
|---|---|---|---|---|---|
| deps.first_checkout (single, outer) | 1378.6 | | | | 1/1 |
| deps.second_checkout (single, outer) | 1071.2 | | | | 1/1 |
| prepare.a (single, outer) | 116.2 | | | | 1/1 |
| prepare.b (single, outer) | 74.2 | | | | 1/1 |
| prepare.c (single, outer) | 81.8 | | | | 1/1 |
| prepare.d (single, outer) | 73.9 | | | | 1/1 |
| prepare.e (single, outer) | 68.8 | | | | 1/1 |
| ready.a (single, outer) | 4990.9 | | | | 1/1 |
| ready.b (single, outer) | 6620.1 | | | | 1/1 |
| repeat.app_read | 988.412 | 1061.521 | 914.1 | 991.028 | 20/20 |
| repeat.entry | 898.312 | 1008.007 | 836.036 | 945.125 | 20/20 |
| setup.first_checkout (single, outer) | 19234.2 | | | | 1/1 |
| setup.second_checkout (single, outer) | 1823.1 | | | | 1/1 |

`ready.<co>` sums start, native readiness and the first verified identity (app deps excluded).
First-checkout timings start from the image's cache state above; they are not universal cold installs.
