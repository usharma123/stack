# BranchBox (branchbox:default) run 20261006t180409-b89259

valid: True · completed: True · transport: host · isolation boundary: container
measurement: diagnostic: timings recorded per check; only passing checks' samples count · reportable: False

Setup scope: not declared
Cache state: image caches not cleared; first-checkout timings may include preseeded caches

| check | status | mode | detail |
|---|---|---|---|
| setup.a | pass | n/a |  |
| lock.created | unsupported | n/a | adapter declares no lock files |
| deps.a | pass | native |  |
| start.a | pass | native | readiness=unsupported pg=5432 redis=6379 |
| migrate.a | pass | native |  |
| crud_cache.a | pass | native |  |
| tests.a | pass | native |  |
| start.repeat | pass | native | start exit 0 |
| setup.b | pass | n/a |  |
| deps.b | pass | native |  |
| start.b | pass | native | readiness=unsupported pg=5432 redis=6379 |
| migrate.b | pass | native |  |
| crud_cache.b | pass | native |  |
| tests.b | pass | native |  |
| isolation | pass | native | boundary=container |
| repeat.entry | pass | native |  |
| repeat.app_read | pass | native |  |
| status | unsupported | n/a | no status command |
| stop.a | pass | native | stop exit 0, probe exit 0, app after stop exit 1 |
| b.survives | pass | n/a |  |
| restart.a | pass | native | readiness=unsupported pg=5432 redis=6379 |
| persist.pg | pass | native |  |
| persist.redis | pass | native | policy={'appendonly': 'yes', 'appendfsync': 'always', 'save': '3600 1 300 100 60 10000', 'dir': '/data'} |
| cache.after_restart | pass | native |  |
| lock.frozen_copy | unsupported | n/a | no frozen/locked setup mode |
| bad_config | blocked | n/a | setup exit 0, start exit 1: environment prerequisite failed before the intended refusal: error getting credentials - err: exit status 1, out: `` |
| occupied_port | not_applicable | n/a | the recipe publishes no host ports; services are reachable only inside each workspace's own Compose network |
| cleanup.processes | pass | native |  |
| cleanup.supervisors | observed | n/a | none |

End-to-end time to first verified work (setup, start, readiness, app deps, identity,
migrate, mark/CRUD/cache, pytest). `steps` sums those receipts; `wall` also includes
harness verification steps. This, not any single setup command, is the cross-tool task time.
It starts from an already PREPARED checkout; prepare (reported separately as prepare.<co>) covers: native `feature start` worktree/config creation (excluded from first_task).

| task | steps s | wall s | receipts | checkout |
|---|---|---|---|---|
| first_task.a | 8.8 | 10.54 | 9 | first in run |
| first_task.b | 7.0 | 8.78 | 9 | second, A's lock, warm caches |

Phase timings (single commands; scopes differ by tool, see Setup scope; do not rank across tools):

| timing | outer p50 ms | outer p95 ms | inner p50 ms | inner p95 ms | ok/n |
|---|---|---|---|---|---|
| deps.first_checkout (single, outer) | 175.2 | | | | 1/1 |
| deps.second_checkout (single, outer) | 169.3 | | | | 1/1 |
| prepare.a (single, outer) | 374.7 | | | | 1/1 |
| prepare.b (single, outer) | 175.4 | | | | 1/1 |
| prepare.d (single, outer) | 196.1 | | | | 1/1 |
| ready.a (single, outer) | 2987.4 | | | | 1/1 |
| ready.b (single, outer) | 3001.7 | | | | 1/1 |
| repeat.app_read | 624.765 | 653.074 | None | None | 20/20 |
| repeat.entry | 161.961 | 174.607 | None | None | 20/20 |
| setup.first_checkout (single, outer) | 1328.4 | | | | 1/1 |
| setup.second_checkout (single, outer) | 573.3 | | | | 1/1 |

`ready.<co>` sums start, native readiness and the first verified identity (app deps excluded).
First-checkout timings start from the image's cache state above; they are not universal cold installs.
