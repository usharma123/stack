# isola (isola:default) run 20261006t180223-37caf7

valid: True · completed: True · transport: docker · isolation boundary: database
measurement: diagnostic: timings recorded per check; only passing checks' samples count · reportable: False

Setup scope: not declared
Cache state: image caches not cleared; first-checkout timings may include preseeded caches

| check | status | mode | detail |
|---|---|---|---|
| setup.a | pass | n/a |  |
| lock.created | unsupported | n/a | adapter declares no lock files |
| deps.a | pass | native |  |
| start.a | pass | scripted | readiness=unsupported pg=25440 redis=26390 |
| migrate.a | pass | native |  |
| crud_cache.a | pass | native |  |
| tests.a | pass | native |  |
| start.repeat | pass | scripted | start exit 0 |
| setup.b | pass | n/a |  |
| deps.b | pass | native |  |
| start.b | pass | scripted | readiness=unsupported pg=25440 redis=26390 |
| migrate.b | pass | native |  |
| crud_cache.b | pass | native |  |
| tests.b | pass | native |  |
| isolation | pass | native | boundary=database |
| repeat.entry | pass | native |  |
| repeat.app_read | pass | native |  |
| status | observed | native | exit 0 |
| stop.a | pass | native | stop exit 0, probe exit 0, app after stop exit 0 |
| stop.a.data_endpoints | observed | n/a | data endpoints still reachable after stop (declared shared-server design) |
| b.survives | pass | n/a |  |
| restart.a | pass | scripted | readiness=unsupported pg=25440 redis=26390 |
| persist.pg | pass | native |  |
| persist.redis | pass | native | policy={'appendonly': 'yes', 'appendfsync': 'always', 'save': '', 'dir': '/home/agent/rwb-shared/redis'} |
| cache.after_restart | pass | native |  |
| lock.frozen_copy | unsupported | n/a | no frozen/locked setup mode |
| bad_config | pass | n/a | setup exit 0, start exit 1 (intended diagnostic) |
| occupied_port | not_applicable | n/a | isola allocates ports only for port-bearing services; PostgreSQL/Redis are shared servers, so a squatted checkout port tests nothing isola owns |
| cleanup.processes | pass | native |  |
| cleanup.supervisors | observed | n/a | none |

End-to-end time to first verified work (setup, start, readiness, app deps, identity,
migrate, mark/CRUD/cache, pytest). `steps` sums those receipts; `wall` also includes
harness verification steps. This, not any single setup command, is the cross-tool task time.
It starts from an already PREPARED checkout; prepare (reported separately as prepare.<co>) covers: git repository + `git worktree add` for B/D/E (excluded from first_task).

| task | steps s | wall s | receipts | checkout |
|---|---|---|---|---|
| first_task.a | 9.47 | 9.93 | 9 | first in run |
| first_task.b | 2.17 | 2.51 | 9 | second, A's lock, warm caches |

Phase timings (single commands; scopes differ by tool, see Setup scope; do not rank across tools):

| timing | outer p50 ms | outer p95 ms | inner p50 ms | inner p95 ms | ok/n |
|---|---|---|---|---|---|
| deps.first_checkout (single, outer) | 584.3 | | | | 1/1 |
| deps.second_checkout (single, outer) | 88.2 | | | | 1/1 |
| prepare.a (single, outer) | 122.5 | | | | 1/1 |
| prepare.b (single, outer) | 70.3 | | | | 1/1 |
| prepare.d (single, outer) | 67.8 | | | | 1/1 |
| ready.a (single, outer) | 769.2 | | | | 1/1 |
| ready.b (single, outer) | 954.8 | | | | 1/1 |
| repeat.app_read | 172.651 | 194.172 | 112.473 | 133.39 | 20/20 |
| repeat.entry | 64.35 | 72.939 | 4.992 | 5.567 | 20/20 |
| setup.first_checkout (single, outer) | 5376.8 | | | | 1/1 |
| setup.second_checkout (single, outer) | 79.4 | | | | 1/1 |

`ready.<co>` sums start, native readiness and the first verified identity (app deps excluded).
First-checkout timings start from the image's cache state above; they are not universal cold installs.
