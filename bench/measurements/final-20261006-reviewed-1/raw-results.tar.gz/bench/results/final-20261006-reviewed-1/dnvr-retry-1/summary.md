# dnvr a66c2bb (tmux runner) (dnvr:default) run 20261006t175437-f511c6

valid: True · completed: True · transport: docker · isolation boundary: service-instance
measurement: diagnostic: timings recorded per check; only passing checks' samples count · reportable: False

Setup scope: not declared
Cache state: image caches not cleared; first-checkout timings may include preseeded caches

| check | status | mode | detail |
|---|---|---|---|
| setup.a | pass | native |  |
| lock.created | pass | native |  |
| deps.a | pass | native |  |
| start.a | pass | native | readiness=scripted pg=25432 redis=26379 |
| migrate.a | pass | native |  |
| crud_cache.a | pass | native |  |
| tests.a | pass | native |  |
| start.repeat | pass | native | start exit 0 |
| setup.b | pass | native |  |
| deps.b | pass | native |  |
| start.b | pass | native | readiness=scripted pg=25433 redis=26380 |
| migrate.b | pass | native |  |
| crud_cache.b | pass | native |  |
| tests.b | pass | native |  |
| isolation | pass | native | boundary=service-instance |
| repeat.entry | pass | native |  |
| repeat.app_read | pass | native |  |
| status | observed | n/a | exit 0 |
| stop.a | pass | scripted | stop exit 0, probe exit 0, app after stop exit 3 |
| b.survives | pass | n/a |  |
| restart.a | pass | native | readiness=scripted pg=25432 redis=26379 |
| persist.pg | pass | native |  |
| persist.redis | pass | native | policy={'appendonly': 'yes', 'appendfsync': 'always', 'save': '3600 1 300 100 60 10000', 'dir': '/home/agent/rwb/a/.dnvr/redis-data'} |
| cache.after_restart | pass | native |  |
| lock.frozen_copy | pass | native | setup exit 0; lock unchanged; versions match; executable paths differ (observed) |
| bad_config | pass | native | setup exit 1 (intended diagnostic) |
| occupied_port | pass | scripted | refused-at-start |
| cleanup.processes | pass | scripted |  |
| cleanup.supervisors | observed | n/a | none |

End-to-end time to first verified work (setup, start, readiness, app deps, identity,
migrate, mark/CRUD/cache, pytest). `steps` sums those receipts; `wall` also includes
harness verification steps. This, not any single setup command, is the cross-tool task time.
It starts from an already PREPARED checkout; prepare (reported separately as prepare.<co>) covers: benchmark glue only: fixture + tool config copy, source token.

| task | steps s | wall s | receipts | checkout |
|---|---|---|---|---|
| first_task.a | 50.03 | 52.26 | 9 | first in run |
| first_task.b | 15.17 | 17.15 | 9 | second, A's lock, warm caches |

Phase timings (single commands; scopes differ by tool, see Setup scope; do not rank across tools):

| timing | outer p50 ms | outer p95 ms | inner p50 ms | inner p95 ms | ok/n |
|---|---|---|---|---|---|
| deps.first_checkout (single, outer) | 1372.4 | | | | 1/1 |
| deps.second_checkout (single, outer) | 905.1 | | | | 1/1 |
| prepare.a (single, outer) | 124.0 | | | | 1/1 |
| prepare.b (single, outer) | 74.7 | | | | 1/1 |
| prepare.c (single, outer) | 71.7 | | | | 1/1 |
| prepare.d (single, outer) | 65.0 | | | | 1/1 |
| prepare.e (single, outer) | 61.7 | | | | 1/1 |
| ready.a (single, outer) | 4451.5 | | | | 1/1 |
| ready.b (single, outer) | 5288.4 | | | | 1/1 |
| repeat.app_read | 976.824 | 1089.532 | 912.757 | 1019.508 | 20/20 |
| repeat.entry | 950.476 | 1043.441 | 878.899 | 968.891 | 20/20 |
| setup.first_checkout (single, outer) | 36051.4 | | | | 1/1 |
| setup.second_checkout (single, outer) | 2562.0 | | | | 1/1 |

Start scope: start-to-ready: PTY driver (`script` + FIFO), `dnvr up`, wait for pg.url/redis.url, detach.

`ready.<co>` sums start, native readiness and the first verified identity (app deps excluded).
First-checkout timings start from the image's cache state above; they are not universal cold installs.
